---
title: "Realism (arts)"
source: "https://en.wikipedia.org/wiki/Realism_%28arts%29"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Realism (arts)

Artistic style of representing subjects realistically

Eilif Peterssen, *Summer Night* (1886)

In art, **realism** is generally the attempt to represent subject-matter truthfully, without artificiality, exaggeration, or speculative or supernatural elements. The term is often used interchangeably with **naturalism**, although these terms are not necessarily synonymous. Naturalism, as an idea relating to visual representation in Western art, seeks to depict objects with the least possible amount of distortion and is tied to the development of linear perspective and illusionism in Renaissance Europe. Realism, while predicated upon naturalistic representation and a departure from the idealization of earlier academic art, often refers to a specific art historical movement that originated in France in the aftermath of the French Revolution of 1848. With artists like Gustave Courbet capitalizing on the mundane, ugly or sordid, realism was motivated by the renewed interest in the commoner and the rise of leftist politics. The realist painters rejected Romanticism, which had come to dominate French literature and art, with roots in the late 18th century.

In 19th-century Europe, "Naturalism" or the "Naturalist school" was somewhat artificially erected as a term representing a breakaway sub-movement of realism, that attempted (not wholly successfully) to distinguish itself from its parent by its avoidance of politics and social issues, and liked to proclaim a quasi-scientific basis, playing on the sense of "naturalist" as a student of natural history, as the biological sciences were then generally known.

There have been various movements invoking realism in the other arts, such as the opera style of verismo, literary realism, theatrical realism and Italian neorealist cinema.

## Visual arts

When used as an adjective, "realistic" (usually related to visual appearance) distinguishes itself from "realist" art that concerns subject matter. Similarly, the term "illusionistic" might be used when referring to the accurate rendering of visual appearances in a composition. In painting, naturalism is the precise, detailed and accurate representation in art of the appearance of scenes and objects. It is also called mimesis or illusionism and became especially marked in European painting in the Early Netherlandish painting of Robert Campin, Jan van Eyck and other artists in the 15th century. In the 19th century, Realism art movement painters such as Gustave Courbet were not especially noted for fully precise and careful depiction of visual appearances; in Courbet's time that was more often a characteristic of academic painting, which very often depicted with great skill and care scenes that were contrived and artificial, or imagined historical scenes.

### Resisting idealization

Francisco Goya, *Charles IV of Spain and His Family*, 1800–01

Realism, or naturalism as a style depicting the unidealized version of the subject, can be used in depicting any type of subject without commitment to treating the typical or the everyday. Despite the general idealism of classical art, this too had classical precedents, which was useful when defending such treatments in the Renaissance and Baroque. Demetrius of Alopece was a 4th-century BCE sculptor whose work (all now lost) was said to prefer realism over ideal beauty, and during the Ancient Roman Republic, politicians preferred a truthful depiction in portraits, though the early emperors favored Greek idealism. Goya's portraits of the Spanish royal family represent a sort of honest, unflattering portrayal of important people.

A recurring trend in Christian art was "realism" that emphasized the humanity of religious figures, above all Christ and his physical sufferings in his Passion. Following trends in devotional literature, this developed in the Late Middle Ages, where some painted wooden sculptures in particular strayed into the grotesque in portraying Christ covered in wounds and blood, with the intention of stimulating the viewer to meditate on the suffering that Christ had undergone on their behalf. These were especially found in Germany and Central Europe. After abating in the Renaissance, similar works re-appeared in the Baroque, especially in Spanish sculpture.

Renaissance theorists opened a debate, which was to last several centuries, as to the correct balance between drawing art from the observation of nature and from idealized forms, typically those found in classical models, or the work of other artists generally. Some admitted the importance of the natural, but many believed it should be idealized to various degrees to include only the beautiful. Leonardo da Vinci was one who championed the pure study of nature and wished to depict the whole range of individual varieties of forms in the human figure and other things. Leon Battista Alberti was an early idealizer, stressing the typical, with others such as Michelangelo supporting the selection of the most beautiful – he refused to make portraits for that reason.

Henri Biva, *Matin à Villeneuve*, c. 1905–06

In the 17th century, the debate continued. In Italy, it usually centered on the contrast between the relative "classical-idealism" of the Carracci and the "naturalist" style of the Caravaggisti, or followers of Caravaggio, who painted religious scenes as though set in the back streets of contemporary Italian cities and used "naturalist" as a self-description. Bellori, writing some decades after Caravaggio's early death and no supporter of his style, refers to "Those who glory in the name of naturalists" (*naturalisti*).

During the 19th century, naturalism developed as a broadly defined movement in European art, though it lacked the political underpinnings that motivated realist artists. The originator of the term was the French art critic Jules-Antoine Castagnary, who in 1863 announced: "The naturalist school declares that art is the expression of life under all phases and on all levels, and that its sole aim is to reproduce nature by carrying it to its maximum power and intensity: it is truth balanced with science". Émile Zola adopted the term with a similar scientific emphasis for his aims in the novel. Many Naturalist paintings covered a similar range of subject matter as that of Impressionism, but using tighter, more traditional brushwork styles.

The term "continued to be used indiscriminately for various kinds of realism" for several decades, often as a catch-all term for art that was outside Impressionism and later movements of Modernism and also was not academic art. The later periods of the French Barbizon School and the Düsseldorf School of painting, with its students from many countries, and 20th-century American Regionalism are movements that are often also described as "naturalist", although the term is rarely used in British painting. Some recent art historians claimed either Courbet or the Impressionists for the label.

- 

 Late Gothic *Pietà* from Lubiąż in Lower Silesia, Poland, now in the National Museum in Warsaw

- 

 Alexei Savrasov, *The Rooks Have Returned*, 1871

- 

 Jean-François Raffaëlli, *Outskirts of Paris*, 1880s

- 

 Pekka Halonen, Finnish Naturalist, *Pioneers in Karelia*, 1900

### Illusionism

Lord Leighton's *Cimabue's Celebrated Madonna* of 1853–55 is at the end of a long tradition of illusionism in painting, but is not Realist in the sense of Courbet's work of the same period.

The development of increasingly accurate representations of the visual appearances of things has a long history in art. It includes elements such as the accurate depiction of the anatomy of humans and animals, the perspective and effects of distance, and the detailed effects of light and color. The art of the Upper Paleolithic in Europe achieved remarkably lifelike depictions of animals. Ancient Egyptian art developed conventions involving both stylization and idealization. Ancient Greek art is commonly recognized as having made great progress in the representation of anatomy. No original works on panels or walls by the great Greek painters survive, but from literary accounts and the surviving corpus of derivative works (mostly Graeco-Roman works in mosaic), illusionism seems to be highly valued in painting. Pliny the Elder's famous story of birds pecking at grapes painted by Zeuxis in the 5th century BC may well be a legend.

As well as accuracy in shape, light, and color, Roman paintings show an unscientific but effective knowledge of representing distant objects smaller than closer ones and representing regular geometric forms such as the roof and walls of a room with perspective. This progress in illusionistic effects in no way meant a rejection of idealism; statues of Greek gods and heroes attempt to represent with accuracy idealized and beautiful forms, though other works, such as heads of the famously ugly Socrates, were allowed to fall below these ideal standards of beauty. Roman portraiture, when not under too much Greek influence, shows a greater commitment to a truthful depiction of its subjects, called verism.

*Bas-de-page* of the *Baptism of Christ*, "Hand G" (Jan van Eyck?), Turin–Milan Hours. An illusionistic work for c. 1425, with the dove of the Holy Ghost in the sky.

The art of Late Antiquity famously rejected illusionism for expressive force, a change already well underway by the time Christianity began to affect the art of the elite. In the West, classical standards of illusionism did not begin to be reached again until the Late medieval and Early Renaissance periods and were helped first in the Netherlands in the early 15th century, and around the 1470s in Italy by the development of new techniques of oil painting which allowed very subtle and precise effects of light to be painted using several layers of paint and glaze. Scientific methods of representing perspective were developed in Italy in the early 15th century and gradually spread across Europe, with accuracy in anatomy rediscovered under the influence of classical art. As in classical times, idealism remained the norm.

The accurate depiction of landscape in painting had also been developing in Early Netherlandish/Early Northern Renaissance and Italian Renaissance painting and was then brought to a very high level in 17th-century Dutch Golden Age painting, with very subtle techniques for depicting a range of weather conditions and degrees of natural light. After being another development of Early Netherlandish painting, 1600 European portraiture subjects were often idealized by smoothing features or giving them an artificial pose. Still life paintings and still life elements in other works played a considerable role in developing illusionistic painting, though in the Netherlandish tradition of flower painting they long lacked "realism", in that flowers from all seasons were typically used, either from the habit of assembling compositions from individual drawings or as a deliberate convention; the large displays of bouquets in vases were atypical of 17th-century habits; the flowers were displayed one at a time.

### Depiction of ordinary subjects

[

Woodcutting, miniature from a set of Labours of the Months by Simon Bening, c. 1550

The depiction of ordinary, everyday subjects in art also has a long history, though it was often squeezed into the edges of compositions or shown at a smaller scale. This was partly because art was expensive and usually commissioned for specific religious, political or personal reasons, which allowed only a relatively small amount of space or effort to be devoted to such scenes. Drolleries in the margins of medieval illuminated manuscripts sometimes contain small scenes of everyday life, and the development of perspective created large background areas in many scenes set outdoors. Medieval and Early Renaissance art usually showed non-sacred figures in contemporary dress by convention.

Early Netherlandish painting brought the painting of portraits as low down the social scale as the prosperous merchants of Flanders, and some of these, notably the *Arnolfini Portrait* by Jan van Eyck (1434) and more often in religious scenes such as the Merode Altarpiece by Robert Campin and his workshop (circa 1427), include very detailed depictions of middle-class interiors full of lovingly depicted objects. However, these objects are at least largely there because they carry layers of complex significance and symbolism that undercut any commitment to realism for its own sake. Cycles of the Labours of the Months in late medieval art, of which many examples survive from books of hours, concentrate on peasants laboring on different tasks through the seasons, often in a rich landscape background, and were significant both in developing landscape art and the depiction of everyday working-class people.

Annibale Carracci, *The Butcher's Shop*, early 1580s

In the 16th century, there was a fashion for the depiction in large paintings of scenes of people working, especially in food markets and kitchens; in many, the food is given as much prominence as the workers. Artists included Pieter Aertsen and his nephew Joachim Beuckelaer in the Netherlands, working in an essentially Mannerist style, and in Italy the young Annibale Carracci in the 1580s, using an unpolished style, with Bartolomeo Passerotti somewhere between the two. Pieter Bruegel the Elder pioneered large panoramic scenes of peasant life. Such scenes acted as a prelude for the popularity of scenes of work in genre painting in the 17th century, which appeared all over Europe, with Dutch Golden Age painting sprouting several different subgenres of such scenes, the Bamboccianti (though mostly from the Low Countries) in Italy, and in Spain the genre of bodegones, and the introduction of unidealized peasants into history paintings by Jusepe de Ribera and Velázquez. The Le Nain brothers in France and many Flemish artists including Adriaen Brouwer and David Teniers the Elder and Younger painted peasants, but rarely townsfolk. In the 18th century, small paintings of working people remained popular, mostly drawing on the Dutch tradition and featuring women.

Much art depicting ordinary people, especially in the form of prints, was comic and moralistic, but the mere poverty of the subjects seems relatively rarely to have been part of the moral message. From the mid-19th century onwards, the difficulties of life for the poor were emphasized. Despite this trend coinciding with large-scale migration from the countryside to cities in most of Europe, painters still tended to paint poor rural people. Crowded city street scenes were popular with the Impressionists and related painters, especially ones showing Paris.

Medieval manuscript illuminators were often asked to illustrate technology, but after the Renaissance, such images continued in book illustrations and prints, with the exception of marine painting which largely disappeared in fine art until the early Industrial Revolution, scenes from which were painted by a few painters such as Joseph Wright of Derby and Philip James de Loutherbourg. Such subjects probably failed to sell very well, and there is a noticeable absence of industry, other than a few railway scenes, in painting until the later 19th century, when works began to be commissioned, typically by industrialists or for institutions in industrial cities, often on a large scale, and sometimes given a quasi-heroic treatment.

American realism, a movement of the early 20th century, is one of many modern movements to use realism in this sense.

- [_-_Google_Art_Project.jpg "Jean-Baptiste Greuze, The Laundress, 1761")

 Jean-Baptiste Greuze, *The Laundress*, 1761

- 

 William Bell Scott *Iron and Coal*, 1855–1860

- 

 Sir Luke Fildes, *The Widower*, 1876

- 

 Albert Edelfelt, *The Luxembourg Gardens*, 1887

### Realist movement

The Realist movement began in the mid-19th century as a reaction to Romanticism and History painting. In favor of depictions of 'real' life, the Realist painters used common laborers, and ordinary people in ordinary surroundings engaged in real activities as subjects for their works. Its chief exponents were Gustave Courbet, Jean-François Millet, Honoré Daumier and Jean-Baptiste-Camille Corot. According to Ross Finocchio, formerly of the Department of European Paintings at the Metropolitan Museum of Art, Realists used unprettified detail depicting the existence of ordinary contemporary life, coinciding with the contemporaneous naturalist literature of Émile Zola, Honoré de Balzac and Gustave Flaubert.

The French Realist movement had equivalents in all other Western countries, developing somewhat later. In particular the Peredvizhniki or *Wanderers* group in Russia who formed in the 1860s and organized exhibitions from 1871 included many realists such as Ilya Repin, Vasily Perov and Ivan Shishkin, and had a great influence on Russian art. In Britain, artists such as Hubert von Herkomer and Luke Fildes had great success with realist paintings dealing with social issues.

- 

 Vasily Perov, *The Drowned*, 1867

- 

 Ilya Repin, *Religious Procession in Kursk Province*, 1880–1883

- 

 Aleksander Gierymski *Feast of Trumpets*, 1884

- 

 Hubert von Herkomer, *Hard Times*, 1885

## Literature

Broadly defined as "the faithful representation of reality", Realism as a literary movement is based on "objective reality." It focuses on showing everyday activities and life, primarily among the middle- or lower-class society, without romantic idealization or dramatization. According to Kornelije Kvas, "the realistic figuration and re-figuration of reality form logical constructs that are similar to our usual notion of reality, without violating the principle of three types of laws – those of natural sciences, psychological and social ones". It may be regarded as a general attempt to depict subjects as they are considered to exist in third-person objective reality without embellishment or interpretation and "in accordance with secular, empirical rules." As such, the approach inherently implies a belief that such reality is ontologically independent of humankind's conceptual schemes, linguistic practices and beliefs and thus can be known to the artist, who can in turn represent this 'reality' faithfully. As Ian Watt states, modern realism "begins from the position that truth can be discovered by the individual through the senses" and as such, "it has its origins in Descartes and Locke, and received its first full formulation by Thomas Reid in the middle of the eighteenth century."

While the preceding Romantic era was also a reaction against the values of the Industrial Revolution, realism was in its turn a reaction to Romanticism, and for this reason it is also commonly derogatorily referred as "traditional bourgeois realism". Some writers of Victorian literature produced works of realism. The rigidities, conventions, and other limitations of "bourgeois realism" prompted in their turn the revolt later labeled as modernism; starting around 1900, the driving motive of modernist literature was the criticism of the 19th-century bourgeois social order and world view, which was countered with an anti-rationalist, anti-realist and anti-bourgeois program.

## Theatre

A photograph taken during the 1922 performance of 'Uncle Vanya' at the Moscow Art Theatre

Theatrical realism is said to have first emerged in European drama in the 19th century as an offshoot of the Industrial Revolution and the age of science. Some also specifically cited the invention of photography as the basis of the realist theater while others view that the association between realism and drama is far older as demonstrated by the principles of dramatic forms such as the presentation of the physical world that closely matches reality.

The achievement of realism in the theatre was to direct attention to the social and psychological problems of ordinary life. In its dramas, people emerge as victims of forces larger than themselves, as individuals confronted with a rapidly accelerating world. These pioneering playwrights present their characters as ordinary, impotent, and unable to arrive at answers to their predicaments. This type of art represents what we see with our human eyes. Anton Chekov, for instance, used camera works to reproduce an uninflected slice of life. Scholars such as Thomas Postlewait noted that throughout the nineteenth and twentieth centuries, there were numerous joining of melodramatic and realistic forms and functions, which could be demonstrated in the way melodramatic elements existed in realistic forms and vice versa.

In the United States, realism in drama preceded fictional realism by about two decades as theater historians identified the first impetus toward realism during the late 1870s and early 1880s. Its development is also attributed to William Dean Howells and Henry James who served as the spokesmen for realism as well as articulator of its aesthetic principles.

The realistic approach to theater collapsed into nihilism and the absurd after World War II.

## Cinema

Italian Neorealism was a cinematic movement incorporating elements of realism that developed in post-WWII Italy. Notable Neorealists included Vittorio De Sica, Luchino Visconti, and Roberto Rossellini. Realist films generally focus on social issues. There are two types of realism in film: seamless realism and aesthetic realism. Seamless realism tries to use narrative structures and film techniques to create a "reality effect" to maintain its authenticity. Aesthetic realism, which was first called for by French filmmakers in the 1930s and promoted by Andre Bazin in the 1950s, acknowledges that a "film cannot be fixed to mean what it shows", as there are multiple realisms; as such, these filmmakers use location shooting, natural light and non-professional actors to ensure the viewer can make up her/his own choice based on the film, rather than being manipulated into a "preferred reading". Siegfried Kracauer is also notable for arguing that realism is the most important function of cinema.

Aesthetically realist filmmakers use long shots, deep focus and eye-level 90-degree shots to reduce manipulation of what the viewer sees. Italian neorealism filmmakers from after WWII took the existing realist film approaches from France and Italy that emerged in the 1960s and used them to create a politically oriented cinema. French filmmakers made some politically oriented realist films in the 1960s, such as the cinéma vérité and documentary films of Jean Rouch while in the 1950s and 1960s, British, French and German new waves of filmmaking produced "slice-of-life" films (e.g., kitchen sink dramas in the UK).

## Opera

Verismo was a post-Romantic operatic tradition associated with Italian composers such as Pietro Mascagni, Ruggero Leoncavallo, Umberto Giordano, Francesco Cilea and Giacomo Puccini. They sought to bring the naturalism of influential late 19th-century writers such as Émile Zola, Gustave Flaubert and Henrik Ibsen into opera. This new style presented true-to-life drama that featured gritty and flawed lower-class protagonists while some described it as a heightened portrayal of a realistic event. Although an account considered Giuseppe Verdi's *Luisa Miller* and *La traviata* as the first stirrings of the verismo, some claimed that it began in 1890 with the first performance of Mascagni's *Cavalleria rusticana*, peaked in the early 1900s. It was followed by Leoncavallo's Pagliacci, which dealt with the themes of infidelity, revenge, and violence.

Verismo also reached Britain where pioneers included the Victorian-era theatrical partnership of the dramatist W. S. Gilbert and the composer Arthur Sullivan (1842–1900). Specifically, their play *Iolanthe* is considered a realistic representation of the nobility although it included fantastical elements.
