---
title: "The Brothers Karamazov"
source: "https://en.wikipedia.org/wiki/The_Brothers_Karamazov"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# The Brothers Karamazov

1880 novel by Fyodor Dostoevsky

The Brothers Karamazov

***The Brothers Karamazov*** (Russian: Братья Карамазовы, romanized: *Brat'ya Karamazovy*,

IPA: ), also translated as ***The Karamazov Brothers***, is the sixteenth and final novel by Russian author Fyodor Dostoevsky. Dostoevsky spent nearly two years writing *The Brothers Karamazov*, which was published as a serial in *The Russian Messenger* from January 1879 to November 1880. Dostoevsky died less than four months after its publication. It has been acclaimed as one of the supreme achievements in world literature.

Set in 19th-century Russia, *The Brothers Karamazov* is a passionate philosophical novel that discusses questions of God, free will, and morality. It has also been described as a theological drama dealing with problems of faith, doubt, and reason in the context of a modernizing Russia, with a plot that revolves around the subject of patricide. Dostoevsky composed much of the novel in Staraya Russa, which inspired the main setting.

## Background

Optina Monastery served as a spiritual center for Russia in the 19th century and inspired many aspects of *The Brothers Karamazov*.

Although Dostoevsky began his first notes for *The Brothers Karamazov* in April 1878, the novel incorporated elements and themes from an earlier unfinished project he had begun in 1869 entitled *The Life of a Great Sinner*. Another unfinished project, *Drama in Tobolsk* (Драма в Тобольске), is considered to be the first draft of the first chapter of *The Brothers Karamazov*. Dated 13 September 1874, it tells of a fictional murder in Staraya Russa committed by a *praporshchik* named Dmitry Ilynskov (based on a real soldier from Omsk), who is thought to have murdered his father. It goes on to note that the father's body was suddenly discovered in a pit under a house. The similarly unfinished *Sorokoviny* (Сороковины), dated 1 August 1875, is reflected in book IX, chapters 3–5 and book XI, chapter nine.

In the October 1877 *Writer's Diary* article "To the Reader", Dostoevsky mentions a "literary work that has imperceptibly and involuntarily been taking shape within me over these two years of publishing the *Diary*." The *Diary* covered a multitude of themes and issues, some of which would be explored in greater depth in *The Brothers Karamazov*. These include patricide, law and order, and a variety of social problems.

The writing of *The Brothers Karamazov* was altered by a personal tragedy: in May 1878, Dostoevsky's three-year-old son Alyosha died of epilepsy, a condition inherited from his father. The novelist's grief is apparent throughout the book. Dostoevsky named the hero Alyosha, and imbued him with qualities that he sought and most admired. His loss is also reflected in the story of Captain Snegiryov and his young son Ilyusha.

The death of his son brought Dostoevsky to the Optina Monastery later that year. There he found inspiration for several aspects of *The Brothers Karamazov*, though at the time he intended to write a novel about childhood instead. Parts of the biographical section of Zosima's life are based on "The Life of the Elder Leonid", a text he found at Optina.

## Major characters

### Fyodor Pavlovich Karamazov

Fyodor Pavlovich, a 55-year-old sensualist and compulsive liar, is the father of three sons — Dmitri, Ivan and Alexei — from two marriages. He is rumored to have also fathered an illegitimate son, Pavel Fyodorovich Smerdyakov, whom he employs as his servant. Fyodor Pavlovich takes no interest in any of his sons at their birth, who are, as a result, raised apart from each other and their father. The relationship between Fyodor and his adult sons drives much of the plot in the novel.

### Dmitri Fyodorovich Karamazov

Dmitri Fyodorovich (often referred to as **Mitya**) is Fyodor Karamazov's 28-year-old eldest son and the only offspring of his first marriage, with Adelaida Ivanovna Miusov. Dmitri is considered to be a sensualist, like his father, and regularly indulges in alcoholism and carousing. Dmitri is brought into contact with his family when he finds himself in need of his inheritance, which he believes is being withheld by his father. He was engaged to be married to Katerina Ivanovna, but breaks that off after falling in love with Grushenka. Dmitri's relationship with his father is the most volatile of the brothers, escalating to violence as he and his father begin fighting over his inheritance and Grushenka. While he maintains a relationship with Ivan, he is closest to his younger brother Alyosha, referring to him as his "cherub".

The character of Dmitri was initially inspired by a convict, D.I. Ilyinsky, whom Dostoevsky met while in prison in Siberia. Ilyinsky, who is described in Dostoevsky's memoir-novel *Notes from the House of the Dead* as "always in the liveliest, merriest spirits", was in prison for murdering his father in order to obtain his inheritance, although he always steadfastly maintained his innocence. He was later freed after another man confessed to the crime.

### Ivan Fyodorovich Karamazov

Ivan Fyodorovich (sometimes also referred to as **Vanya**) is the 24-year-old middle son, and the first from Fyodor Pavlovich's second marriage. Ivan is reserved and aloof, but also intellectually brilliant. His dictum "if there is no God, everything is lawful" is a recurring motif in the novel. At first, Ivan seems not to have much time for his brother Alyosha, but later their bond and mutual affection deepens. He finds his father repulsive, and also has a strong antipathy towards Dmitri. Fyodor Pavlovich tells Alyosha that he fears Ivan more than he fears Dmitri. Ivan falls in love with Katerina Ivanovna, but their intimacy develops in the shadow of her prior connection to Dmitri, and her ambivalence is a source of torment to him.

Some of the most acclaimed passages of the novel involve Ivan, including the chapters "Rebellion" and "The Grand Inquisitor" from Book V, and the three conversations with Smerdyakov and the subsequent chapter "Ivan's nightmare of the devil" in Book XI. Book V, entitled "Pro and Contra", is primarily about "the inner debate taking place in Ivan between his recognition of the moral sublimity of the Christian ideal and his outrage against a universe of pain and suffering." Ivan's rejection of God is posited in terms of the Christian value of compassion — the value that Dostoevsky himself (through the character of Prince Myshkin in *The Idiot*) called "the chief and perhaps the only law of all human existence." Thus Ivan's rejection of God is justified by the very principle at the heart of Christianity. For Ivan the absurdity of all human history is proven by the senselessness of the suffering of children: if reason or rationality is the measure, God's world *cannot* be accepted. All the examples Ivan gives of horrors perpetrated against children were taken by Dostoevsky from actual newspaper accounts and historical sources.

### Alexei Fyodorovich Karamazov

Alexei Fyodorovich (often referred to as **Alyosha**) is, at age 20, the youngest of the brothers. He is the second child of Fyodor Pavlovich's second wife, Sofya Ivanovna, and is thus Ivan's full brother. The narrator identifies him as the hero of the novel in the opening chapter, as does the author in the preface. At the outset of the events, Alyosha is a novice in the local Russian Orthodox monastery. His faith is in contrast to his brother Ivan's atheism. The Elder, Father Zosima, who is a father figure and spiritual guide to Alyosha throughout the book, sends him into the world, where he becomes involved with the extreme personalities and fraught relationships in his family and elsewhere. At all times he acts as a compassionate and insightful peace maker, and is loved by virtually everyone.

In creating the character of Alyosha, Dostoevsky was in large part addressing himself to the contemporary Russian radical youth, as a positive alternative to the atheistic approach to justice and attainment of the good. Alyosha embodies the same aspiration to a society governed by goodness and compassion that is contained in the Socialist ideal, but not divorced from faith in God, from faith in the immortality of the soul in God, or from the Eastern Orthodox Christian tradition in Russia.

### Pavel Fyodorovich Smerdyakov

Pavel Fyodorovich Smerdyakov is the son of "Reeking Lizaveta", a mute woman of the street who died alone giving birth to the child in Fyodor Pavlovich's bathhouse: the name "Smerdyakov" means "son of the reeking one". He is rumored to be the illegitimate son of Fyodor Pavlovich. He was brought up by Fyodor Pavlovich's trusted servant Grigory Vasilievich and his wife Marfa. Grigory tutored him and attempted to give him religious instruction, but Smerdyakov responded with ingratitude and derision. On one occasion Grigory had struck him violently across the face: a week later Smerdyakov had his first epileptic seizure. The narrator notes that as a child, Smerdyakov was fond of hanging cats and giving them ritualistic burials. Grigory told him: "You're not human. You're the spawn of the mildew on the bathhouse wall, that's who you are" — a remark for which Smerdyakov never forgave him. Smerdyakov becomes part of the Karamazov household as a servant, working as Fyodor Pavlovich's lackey and cook. Generally contemptuous of others, Smerdyakov greatly admires Ivan, shares his atheism, and is influenced by his dictum that "everything is lawful". Despite his evident shrewdness, other characters — particularly Ivan, Dmitri and Fyodor Pavlovich — underestimate his intelligence.

Character names

### Agrafena Alexandrovna Svetlova

Agrafena Alexandrovna Svetlova, usually referred to as 'Grushenka', is a beautiful and fiery 22-year-old woman with an uncanny charm for men. In her youth she was jilted by a Polish officer and subsequently came under the protection of a tyrannical miser. The episode leaves Grushenka with an urge for independence and control of her life. Grushenka inspires complete admiration and lust in both Fyodor and Dmitri Karamazov. Their rivalry for her affection becomes the main focus of their conflict, a state of affairs that Grushenka is happy to take advantage of for her own satisfaction and amusement. Belatedly, she realizes that she truly loves Dmitri, and becomes ashamed of her cruelty. Her growing friendship with Alyosha leads her toward a path of spiritual redemption, and hidden qualities of gentleness and generosity emerge, though her fiery temper and pride remain intact.

### Katerina Ivanovna Verkhovtseva

Katerina Ivanovna (sometimes referred to as **Katya**) is Dmitri's beautiful fiancée, despite his open forays with Grushenka. Her engagement to Dmitri is chiefly a matter of pride on both their parts, Dmitri having bailed her father out of a debt. Katerina is extremely proud and seeks to act as a noble martyr. Because of this, she cannot bring herself to act on her love for Ivan, and constantly creates moral barriers between him and herself.

### Father Zosima, the Elder

Father Zosima is an Elder and spiritual advisor (*starets*) in the town monastery and Alyosha's teacher. He is something of a celebrity among the townspeople for his reputed prophetic and healing abilities. His spiritual status inspires both admiration and jealousy among his fellow monks. Zosima provides a refutation to Ivan's atheistic arguments and helps to explain Alyosha's character. Zosima's teachings shape the way Alyosha deals with the young boys he meets in the Ilyusha storyline.

Dostoevsky's intent with the character of Zosima (as with Alyosha) was to portray the Church as a positive social ideal. The character was to some extent based on Father Ambrose of the Optina Monastery, who Dostoevsky had met on a visit to the monastery in 1878. For Zosima's teachings in Book VI, "The Russian Monk", Dostoevsky wrote that the prototype is taken from certain teachings of Tikhon of Zadonsk and "the naïveté of style from the monk Parfeny's book of wanderings". The style and tone in Book VI, where Zosima narrates, is markedly different from the rest of the novel. V. L. Komarovich suggests that the rhythm of the prose is "a departure from all the norms of modern syntax, and at the same time imparts to the entire narration a special, emotional colouring of ceremonial and ideal tranquility."

### Ilyusha

Ilyusha (sometimes called **Ilyushechka**) is a local schoolboy, and the central figure of a crucial subplot in the novel. Dmitri assaults and humiliates his father, the impoverished officer Captain Snegiryov, who has been hired by Fyodor Pavlovich to threaten Dmitri over his debts, and the Snegiryov family is brought to shame as a result. Ilyusha is frequently bullied by his classmates for his father's humiliation, and as a result acts out violently. However behind this aggressive exterior, he is fiercely loyal to his family. His relationship with another schoolboy, Kolya Krasotkin, is a vital part of his plotline.

## Synopsis

### Book One: *A Nice Little Family*

The opening of the novel introduces the Karamazov family and relates the story of their distant and recent past. The details of Fyodor Pavlovich's two marriages, as well as his indifference to the upbringing of his three children, is chronicled. The narrator also establishes the widely varying personalities of the three brothers and the circumstances that have led to their return to their father's town. The first book concludes by describing the mysterious Eastern Orthodox tradition of the Elders. Alyosha has become devoted to the Elder at the local monastery.

### Book Two: *An Inappropriate Gathering*

Book Two begins as the Karamazov family arrives at the monastery so that the Elder Zosima can act as a mediator between Dmitri and his father in their dispute over the inheritance. It was the father's idea, apparently as a joke, to have the meeting take place in such a holy place in the presence of the famous Elder. Fyodor Pavlovich's deliberately insulting and provocative behaviour destroys any chance of conciliation, and the meeting only results in intensified hatred and a scandal. This book also contains a scene in which the Elder Zosima consoles a woman mourning the death of her three-year-old son. The poor woman's grief parallels Dostoevsky's own tragedy at the loss of his young son Alyosha.

### Book Three: *Sensualists*

An original page of book 3, chapter 3 of *The Brothers Karamazov*

The third book provides more details of the love triangle among Fyodor Pavlovich, his son Dmitri, and Grushenka. Dmitri hides near his father's home to see if Grushenka will arrive. His personality is explored in a long conversation with Alyosha. Later that evening, Dmitri bursts into his father's house and assaults him. As he leaves, he threatens to come back and kill him. This book also introduces Smerdyakov and his origins, as well as the story of his mother, Lizaveta Smerdyashchaya. At the conclusion of this book, Alyosha is witness to Grushenka's humiliation of Dmitri's betrothed Katerina Ivanovna.

### Book Four: *Lacerations/Strains*

This section introduces a side story which resurfaces in more detail later in the novel. It begins with Alyosha observing a group of schoolboys throwing rocks at one of their sickly peers named Ilyusha. When Alyosha admonishes the boys and tries to help, Ilyusha bites Alyosha's finger. It is later learned that Ilyusha's father, a former staff-captain named Snegiryov, was assaulted by Dmitri, who dragged him by the beard out of a bar. Alyosha soon learns of the further hardships present in the Snegiryov household and offers the former staff captain money as an apology for his brother and to help Snegiryov's ailing wife and children. After initially accepting the money with joy, Snegiryov throws it to the ground and stomps it into the sand, before running back into his home.

### Book Five: *Pro and Contra*

Here, the rationalist and nihilistic ideology that permeated Russia at this time is defended and espoused by Ivan Karamazov while meeting his brother Alyosha at a restaurant. In the chapter titled "Rebellion", Ivan proclaims that he rejects the world that God has created because it is built on a foundation of suffering. In perhaps the most famous chapter in the novel, "The Grand Inquisitor", Ivan narrates to Alyosha his imagined poem that describes an encounter between a leader from the Spanish Inquisition and Jesus, who has made his return to Earth. The opposition between reason and faith is dramatised and symbolised in a forceful monologue of the Grand Inquisitor who, having ordered the arrest of Jesus, visits him in prison at night.

> Why hast Thou come now to hinder us? For Thou hast come to hinder us, and Thou knowest that...We are working not with Thee but with him [Satan]...We took from him what Thou didst reject with scorn, that last gift he offered Thee, showing Thee all the kingdoms of the earth. We took from him Rome and the sword of Caesar, and proclaimed ourselves sole rulers of the earth...We shall triumph and shall be Caesars, and then we shall plan the universal happiness of man.

The Grand Inquisitor accuses Jesus of having inflicted on humankind the "burden" of free will. At the end of the Grand Inquisitor's lengthy arguments, Jesus silently steps forward and kisses the old man on the lips. The Inquisitor, stunned and moved, tells him he must never come there again, and lets him out. Alyosha, after hearing the story, goes to Ivan and kisses him softly on the lips. Ivan shouts with delight. The brothers part with mutual affection and respect.

### Book Six: *The Russian Monk*

The sixth book relates the life and history of the Elder Zosima as he lies near death in his cell. Zosima explains that he found his faith in his rebellious youth, after an unforgivable action toward his trusted servant, consequently deciding to become a monk. Zosima preaches people must forgive others by acknowledging their own sins and guilt before others. He explains that no sin is isolated, making everyone responsible for their neighbor's sins. Zosima represents a philosophy that responds to Ivan's, which had challenged God's creation in the previous book.

### Book Seven: *Alyosha*

The book begins immediately following the death of Zosima. It is a commonly held perception in the town and the monastery that true holy men's bodies are incorrupt, i.e., they do not succumb to putrefaction. Thus, the expectation concerning the Elder Zosima is that his deceased body will not decompose. It therefore comes as a great shock that Zosima's body not only decays, but begins the process almost immediately following his death. Within the first day, the smell is already unbearable. For many this calls into question their previous respect and admiration for Zosima. Alyosha is particularly devastated by the sullying of Zosima's name due to nothing more than the corruption of his dead body. One of Alyosha's companions in the monastery — Rakitin — uses Alyosha's vulnerability to set up a meeting between him and Grushenka. However, instead of Alyosha becoming corrupted, he acquires new faith and hope from Grushenka, while Grushenka's troubled mind begins the path of spiritual redemption through his influence: they become close friends. The book ends with the spiritual regeneration of Alyosha as he embraces and kisses the earth outside the monastery (echoing, perhaps, Zosima's last earthly act before his death) and cries convulsively. Renewed, he goes back out into the world, as his Elder instructed.

### Book Eight: *Mitya*

This section deals primarily with Dmitri's wild and distraught pursuit of money for the purpose of running away with Grushenka. Dmitri owes money to his fiancée Katerina Ivanovna, and will believe himself to be a thief if he does not find the money to pay her back before embarking on his quest for Grushenka. Dmitri approaches Grushenka's benefactor, Samsonov, who sends him to a neighboring town on a fabricated promise of a business deal. All the while Dmitri is petrified that Grushenka may go to his father and marry him because of his wealth and lavish promises. When Dmitri returns from his failed dealing in the neighboring town, he escorts Grushenka to her benefactor's home, but later discovers that she has deceived him and left early. Furious, he runs to his father's home with a brass pestle in his hand, and spies on him from the window. He takes the pestle from his pocket. There is a discontinuity in the action, and Dmitri is suddenly running from his father's property. The servant Grigori tries to stop him, yelling "Parricide!", but Dmitri hits him in the head with the pestle. Dmitri, afraid that the blow might have killed Grigori, tries to attend to the wound with his handkerchief, but gives up and runs away.

Dmitri is next seen in a daze on the street, covered in blood, with a pile of money in his hand. He soon learns that Grushenka's former betrothed has returned and taken her to a nearby lodge. Upon learning this, Dmitri loads a cart with food and wine and pays for a huge orgy to finally confront Grushenka in the presence of her old flame, intending all the while to kill himself at dawn. The "first and rightful lover" is a boorish Pole who cheats the party at a game of cards. When his deception is revealed, he flees, and Grushenka soon reveals to Dmitri that she really is in love with him. The party rages on, and just as Dmitri and Grushenka are making plans to marry, the police enter the lodge and inform Dmitri that he is under arrest for the murder of his father.

### Book Nine: *The Preliminary Investigation*

Book Nine introduces the details of Fyodor Pavlovich's murder and describes the interrogation of Dmitri, who vigorously maintains his innocence. The alleged motive for the crime is robbery. Dmitri was known to have been completely destitute earlier that evening, but is suddenly seen with thousands of rubles shortly after his father's murder. Meanwhile, the three thousand rubles that Fyodor Pavlovich had set aside for Grushenka have disappeared. Dmitri explains that the money he spent that evening came from three thousand rubles that Katerina Ivanovna gave him to send to her sister. He spent half that at his first meeting with Grushenka — another drunken orgy — and sewed up the rest in a cloth, intending to give it back to Katerina Ivanovna. The investigators are not convinced by this. All of the evidence points toward Dmitri; the only other person in the house at the time of the murder, apart from Gregory and his wife, was Smerdyakov, who was incapacitated due to an epileptic seizure he suffered the day before. As a result of the overwhelming evidence against him, Dmitri is formally charged with the murder and taken away to prison to await trial.

### Book Ten: *Boys*

*Boys* continues the story of the schoolboys and Ilyusha last referred to in Book Four. The book begins with the introduction of the young boy Kolya Krasotkin. Kolya is a brilliant boy who proclaims his atheism, socialism, and beliefs in the ideas of Europe. Dostoevsky uses Kolya's beliefs, especially in a conversation with Alyosha, to satirize his Westernizer critics by putting their words and beliefs in the mouth of a young boy who doesn't really understand what he is talking about. Kolya is bored with life and constantly torments his mother by putting himself in danger. As part of a prank Kolya lies between railroad tracks as a train passes over and becomes something of a legend for the feat. All the other boys look up to Kolya, especially Ilyusha. Since the narrative left Ilyusha in Book Four, his illness has progressively worsened and the doctor states that he will not recover. Kolya and Ilyusha had a falling out over Ilyusha's maltreatment of a local dog: Ilyusha had fed it a piece of bread in which he had placed a pin, at the bidding of Smerdyakov. But thanks to Alyosha's intervention the other schoolboys have gradually reconciled with Ilyusha, and Kolya soon joins them at his bedside. It is here that Kolya first meets Alyosha and begins to reassess his nihilist beliefs.

### Book Eleven: *Brother Ivan Fyodorovich*

Book Eleven chronicles Ivan Fyodorovich's influence on those around him and his descent into madness. It is in this book that Ivan meets three times with Smerdyakov, desperately seeking to solve the riddle of the murder and whether Smerdyakov, and consequently he himself, had anything to do with it. In the final meeting Smerdyakov confesses that he had faked the fit, murdered Fyodor Pavlovich, and stolen the money, which he presents to Ivan. Smerdyakov expresses disbelief at Ivan's professed ignorance and surprise. Smerdyakov claims that Ivan was complicit in the murder by telling Smerdyakov when he would be leaving Fyodor Pavlovich's house, and more importantly by instilling in Smerdyakov the belief that, in a world without God, "everything is permitted." The book ends with Ivan having a hallucination in which he is visited by the devil, in the form of an idle and parasitic former gentleman, who torments him by personifying and caricaturing his thoughts and ideas. The nightmare is interrupted by a knocking at the window: it is Alyosha, who has come to inform him that Smerdyakov has hanged himself. Although the devil disappears, Ivan remains in a delirium and converses irrationally. Alyosha is shocked at his brother's condition and tries to pacify him, but Ivan's ravings become increasingly incoherent. Eventually he falls into a deep sleep.

### Book Twelve: *A Judicial Error*

This book details the trial of Dmitri Karamazov for the murder of his father. The courtroom drama is sharply satirized by Dostoevsky. The men in the crowd are presented as resentful and spiteful, and the women as irrationally drawn to the romanticism of Dmitri's love triangle with Katerina and Grushenka. Ivan's madness takes its final hold over him and he is carried away from the courtroom after his attempt to give evidence about Smerdyakov descends into incomprehensible raving. The turning point in the trial is Katerina's damning testimony. Shocked by Ivan's madness, she passionately defends him and abandons her 'honourable' approach to Dmitri. She produces a letter drunkenly written by Dmitri saying that he would kill his father. The section concludes with lengthy and impassioned closing remarks from the prosecutor and the defence counsel and the verdict that Dmitri is guilty.

### Epilogue

The final section opens with discussion of a plan developed for Dmitri's escape from his sentence of twenty years of hard labor in Siberia. The plan is never fully described, but it seems to involve Ivan and Katerina bribing some guards. Alyosha cautiously approves, because he feels that Dmitri is not emotionally ready to submit to such a harsh sentence, that he is innocent, and that no guards or officers would suffer for aiding the escape. Dmitri and Grushenka plan to escape to America and work the land there for several years, and then return to Russia under assumed American names, because they cannot imagine living without Russia. Dmitri begs for Katerina to visit him in the hospital, where he is recovering from an illness, before he is due to be taken away. When she does, Dmitri apologizes for having hurt her; she in turn apologizes for bringing up the implicating letter during the trial. They agree to love each other for that one moment, and say they will love each other forever, even though both now love other people. The novel concludes at Ilyusha's funeral, where Ilyusha's schoolboy friends listen to Alyosha's "Speech by the Stone". Alyosha promises to remember Kolya, Ilyusha, and all the boys and keep them close in his heart, even though he will have to leave them and may not see them again until many years have passed. He implores them to love each other and to always remember Ilyusha, and to keep his memory alive in their hearts, and to remember this moment at the stone when they were all together and they all loved each other. Alyosha then recounts the Christian promise that they will all be united one day after the Resurrection. In tears, the twelve boys promise Alyosha that they will keep each other in their memories forever. They join hands, and return to the Snegiryov household for the funeral dinner, chanting "Hurrah for Karamazov!"

## Themes

### Faith and atheism

One of the novel's central themes is the counterposition of the true spiritual meaning of the Eastern Orthodox Christian faith, particularly insofar as it is posited as the heart of Russian national identity and history, with the ideas and values emanating from the new doctrines of atheism, rationalism, socialism and nihilism. Not only were these ideas and values alien to Russia's spiritual heritage, they were, in Dostoevsky's opinion, actively working to destroy it, and moreover were becoming increasingly popular and influential, especially among Russia's youth. The theme had already been vividly depicted in all the earlier major novels, particularly *Demons*, but in *The Brothers Karamazov* Dostoevsky artistically represents and counterposes the two antithetical worldviews in archetypal forms — the character of Ivan Fyodorovich and his legend of The Grand Inquisitor, and the characters of Alyosha and the Elder Zosima in their expression and embodiment of a *lived* Christian faith.

The character of Ivan Fyodorovich, though he outwardly plays the role of devil's advocate, is inwardly far from being resolved in his atheism. A constantly reappearing motif in the novel is his proposition that without faith in immortality, there is no such thing as virtue, and that if there is no God, *everything* is permitted. When Zosima encounters the idea in the meeting at the monastery, he doesn't dispute it, but suggests to Ivan that since in all probability he doesn't believe in the immortality of his own soul, his thoughts must be a source of torment to him: "But the martyr likes sometimes to divert himself with his despair, as it were driven to it by despair itself. Meanwhile... you divert yourself with magazine articles, and discussions in society, though you don't believe your own arguments, and with an aching heart mock at them inwardly.... That question you have not answered, and it is your great grief, for it clamors for an answer." In his relations with Ivan, Alyosha consciously personifies the loving voice of faith that he knows lives in his brother's soul, in opposition to the mocking voice of doubt that ultimately becomes personified in the nightmare of the Devil. Alyosha says of Ivan "His mind is a prisoner of his soul. There is a great and unresolved thought in him. He is one of those who don't need millions, they just need to get a thought straight."

Dostoevsky wrote to his editor that his intention with book V, "Pro and Contra", was to portray "the seed of the idea of destruction in our time in Russia among the young people uprooted from reality". This seed is depicted as: "the rejection not of God but of the meaning of His creation. Socialism has sprung from the denial of the meaning of historical reality and ended in a program of destruction and anarchism." In the chapter "Rebellion", the rationale behind Ivan's rejection of God's world is expounded in a long dialogue with Alyosha, in which he justifies his atheism on the grounds of the very principle — universal love and compassion — that is at the heart of the Christian faith. The unmitigated evil in the world, particularly as it relates to the suffering of children, is not something that *can* be accepted by a heart steeped in love, so Ivan feels bound in his conscience to "humbly return the ticket" to God. The idea of the refusal of love on the grounds of love is taken further in the subsequent "Legend of the Grand Inquisitor". In a long dialogue, in which the second participant (the returned Christ) remains silent for its entire duration, the Inquisitor rejects the freedom and spiritual beauty of Christ's teaching as being beyond the capability of earthly humanity, and affirms instead the bread-and-chains materialism derived from the Devil's Temptations as being the only realistic and truly compassionate basis for the government of men. The Legend is Ivan's confession of the struggle of "pro and contra" taking place within his own soul in relation to the problem of faith. According to Mikhail Bakhtin, "both the very form of its construction as The Grand Inquisitor's dialogue with Christ and at the same time with himself, and the very unexpectedness and duality of its finale, indicate an internally dialogic disintegration at its ideological core."

With Book VI, "The Russian Monk", Dostoevsky sought to provide the refutation of Ivan's negation of God, through the teachings of the dying Elder, Zosima. The dark world of the Inquisitor's reasoning is juxtaposed with the radiant, idyllically stylized communications of the dying Elder and Alyosha's renderings of his life and teachings. Zosima, though suffering and near death, unreservedly communicates his love for those around him, and recounts the stories of the crucial moments in his progress along the spiritual path. Alyosha records these accounts for posterity, as well as the Elder's teachings and discourses on various subjects, including: the significance of the Russian Monk; spiritual brotherhood between masters and servants; the impossibility of judging one's fellow creatures; Faith, Prayer, Love, and Contiguity with Other Worlds; and the spiritual meaning of 'hell' as the suffering of being unable to Love. Dostoevsky based Zosima's teachings on those of the 18th century Russian Orthodox saint and spiritual writer Tikhon of Zadonsk, and constructed them around his own formulation of the essence of a true Christian faith: that all are responsible for all, and that "everyone is guilty before all and for everything, and *therefore* everyone is strong enough also to forgive everything for others". He was acutely aware of the difficulty of the artistic task he had set himself and of the incompatibility of the form and content of his "reply" with ordinary discourse and the everyday concerns of his contemporaries.

### Freedom and mechanistic psychology

> "Dostoevsky could hear dialogic relationships everywhere, in all manifestations of conscious and intelligent human life. Where consciousness began, there dialogue began also. Only purely mechanistic relationships are not dialogic, and Dostoevsky categorically denied their importance for understanding and interpreting life and the acts of man."

Throughout the novel, in the very nature of all the characters and their interactions, the freedom of the human personality is affirmed, in opposition to any form of deterministic reduction. The "physiologism" that is being attacked is identified in the repeated references to Claude Bernard, who becomes for Dmitri a despised symbol of the scientific reduction of the human soul to impersonal physiological processes. For Dmitri the word 'Bernard' becomes the most contemptuous of insults. References to Bernard are in part a response to Zola's theories about heredity and environment, gleaned from Bernard's ideas, which functioned as the ideological background to the *Les Rougon-Macquart* series of novels.

Though the affirmation of freedom and rejection of mechanistic psychology is most openly and forcefully expressed through the character of Dmitri, as a theme it pervades the entire novel and virtually all of Dostoevsky's other writings. Bakhtin discusses it in terms of what he calls the *unfinalizability* of Dostoevsky's characters. In Dostoevsky, a fundamental refusal to be wholly defined by an external source (another person, a social interpretation, an ideology, a system of 'knowledge', or anything at all that places a finalizing limit on the primordial freedom of the living soul, including even death) is at the heart of the character. He sees this quality as essential to the human being, to *being human*, and in his most fiercely independent characters, such as Ivan and Dmitri in *The Brothers Karamazov*, Raskolnikov in *Crime and Punishment*, Nastasya Filippovna and Ippolit in *The Idiot*, or the Underground man in *Notes From Underground*, it is actively expressed in virtually all their words and deeds. According to Bakhtin, for Dostoevsky:

> A man never coincides with himself. One cannot apply the formula of identity A≡A. In Dostoevsky's artistic thinking the genuine life of the personality takes place at the point of non-coincidence between a man and himself, at his point of departure beyond the limits of all that he is as a material being – a being that can be spied on, defined, predicted apart from its own will, "at second hand". The genuine life of the personality is made available only through a *dialogic* penetration of that personality, during which it freely and reciprocally reveals itself.

## Style

Dostoyevsky's notes for Chapter 5 of *The Brothers Karamazov*

Although written in the 19th century, *The Brothers Karamazov* displays a number of modern elements. Dostoevsky composed the book with a variety of literary techniques. Though privy to many of the thoughts and feelings of the protagonists, the narrator is a self-proclaimed writer; he discusses his own mannerisms and personal perceptions so often in the novel that he becomes a character. Through his descriptions, the narrator's voice merges imperceptibly into the tone of the people he is describing, often extending into the characters' most personal thoughts. There is no voice of authority in the story. In addition to the principal narrator, there are several sections narrated by other characters entirely, such as the story of The Grand Inquisitor and Zosima's confessions.

Dostoevsky uses individual styles of speech to express the inner personality of each person. For example, the attorney Fetyukovich (based on Vladimir Spasovich) is characterized by malapropisms (e.g. 'robbed' for 'stolen', and at one point declares possible suspects in the murder 'irresponsible' rather than innocent). Several plot digressions provide insight into other apparently minor characters. For example, the narrative in Book Six is almost entirely devoted to Zosima's biography, which contains a confession from a man whom he met many years before. Dostoevsky does not rely on a single source or a group of major characters to convey the themes of this book, but uses a variety of viewpoints, narratives and characters throughout.

## Reception and influence

*The Brothers Karamazov* has had a deep influence on many public figures over the years for widely varying reasons. Admirers include scientists such as Albert Einstein, philosophers Ludwig Wittgenstein and Martin Heidegger, as well as writers such as Virginia Woolf, Cormac McCarthy, Haruki Murakami, Franz Kafka, and Frederick Buechner.

British writer C. P. Snow writes of Einstein's admiration for the novel: "*The Brothers Karamazov*—that for him in 1919 was the supreme summit of all literature. It remained so when I talked to him in 1937, and probably until the end of his life."

Sigmund Freud called it "the most magnificent novel ever written" and was fascinated with what he saw as its Oedipal themes. In 1928 Freud published a paper titled "Dostoevsky and Parricide" in which he investigated Dostoevsky's own neuroses. Freud claimed that Dostoevsky's epilepsy was not a natural condition but instead a physical manifestation of the author's hidden guilt over his own father's death. According to Freud, Dostoevsky (and all other sons) wished for the death of his father because of latent desire for his mother; citing the fact that Dostoevsky's epileptic fits began at age 18, the year his father died. It followed that more obvious themes of patricide and guilt, especially in the form of the moral guilt illustrated by Ivan Karamazov, were further literary evidence of his theory.

Franz Kafka felt indebted to Dostoevsky and *The Brothers Karamazov*, calling himself and Dostoevsky "blood relatives" and was immensely interested in the hatred the brothers demonstrated toward their father in the novel. He probably found parallels with his own strained father-son relationship and drew on this theme to some extent in his works, especially the short story "The Judgment").

James Joyce wrote:

> [Leo] Tolstoy admired him but he thought that he had little artistic accomplishment or mind. Yet, as he said, 'he admired his heart', a criticism which contains a great deal of truth, for though his characters do act extravagantly, madly, almost, still their basis is firm enough underneath.... *The Brothers Karamazov*... made a deep impression on me... he created some unforgettable scenes [detail].... Madness you may call it, but therein may be the secret of his genius.... I prefer the word exaltation, exaltation which can merge into madness, perhaps. In fact all great men have had that vein in them; it was the source of their greatness; the reasonable man achieves nothing.

Not all reception to the book was positive. Some were critical of it, such as Henry James, Vladimir Nabokov, D. H. Lawrence, and Pyotr Ilyich Tchaikovsky. Tchaikovsky, for instance, once said of the novel in a letter that "Dostoyevsky is a writer of genius, but an antipathetic one."

As for Leo Tolstoy himself, the work appears to have proved both challenging and provocative. Entries from his journal indicate that, like others, he considered Dostoevsky's idiosyncratic style to be an obstacle, yet the book was one of several that he requested accompany him on his deathbed.

The philosopher Ludwig Wittgenstein is said to have read *The Brothers Karamazov* "so often he knew whole passages of it by heart". A copy of the novel was one of the few possessions Wittgenstein brought with him to the front during World War I.

Martin Heidegger identified Dostoevsky's thought as one of the most important sources for his early and best known book, *Being and Time*. Of the two portraits Heidegger kept on the wall of his office, one was of Dostoevsky.

According to philosopher Charles B. Guignon, the novel's most fascinating character, Ivan Karamazov, had by the middle of the twentieth century become the icon of existentialist rebellion in the writings of existentialist philosophers Albert Camus and Jean-Paul Sartre. Camus centered on a discussion of Ivan Karamazov's revolt in his 1951 book *Rebel*. Ivan's poem "The Grand Inquisitor" is arguably one of the best-known passages in modern literature due to its ideas about human nature, freedom, power, authority, and religion, as well as for its fundamental ambiguity. A reference to the poem can be found in English novelist Aldous Huxley's *Brave New World Revisited* and American writer David Foster Wallace's novel *Infinite Jest*.

Nobel Prize laureate William Faulkner reread the book regularly, claiming it as his greatest literary inspiration next to Shakespeare's works and the Bible. He once wrote that American literature had yet to produce anything great enough to compare with Dostoyevsky's novel.

In an essay on *The Brothers Karamazov,* written after the Russian Revolution and the First World War, Nobel Prize-winning author Hermann Hesse described Dostoevsky as not a "poet" but a "prophet". British writer W. Somerset Maugham included the book in his list of ten greatest novels in the world.

Contemporary Turkish Nobel Prize-winning writer Orhan Pamuk said during a lecture in St. Petersburg that the first time he read *The Brothers Karamazov*, his life was changed. He felt Dostoyevsky, through his storytelling, revealed completely unique insight into life and human nature.

American philosophical novelist Walker Percy said in an interview:

> I suppose my model is nearly always Dostoevsky, who was a man of very strong convictions, but his characters illustrated and incarnated the most powerful themes and issues and trends of his day. I think maybe the greatest novel of all time is *The Brothers Karamazov* which...almost prophesies and prefigures everything—all the bloody mess and the issues of the 20th century.

Pope Benedict XVI cited the book in the 2007 encyclical *Spe Salvi*.

Soviet leader Joseph Stalin had read Dostoevsky since his youth and considered the author as a great psychologist. His copy of *The Brothers Karamazov* reveals extensive highlights and notes in the margins that he made while reading the work, which have been studied and analyzed by multiple researchers.

According to Serbian state news agency Tanjug, Serbian president Aleksandar Vučić described Dostoevsky as his best-loved novelist, saying: "*The Brothers Karamazov* may be the best work of world literature." American First Lady Laura Bush has said she is an admirer of the novel. Former United States secretary of state and First Lady Hillary Clinton mentioned the novel as her favorite book of all time.

## Translations

Although *The Brothers Karamazov* has been translated from the original Russian into a number of languages, the novel's diverse array of distinct voices and literary techniques makes its translation difficult. Constance Garnett published a translation in 1912, which Garth Terry called "the first adequate English translation". A dramatization (by Isabel Florence Hapgood) was published in 1905.

In 1958, David Magarshack and Manuel Komroff released translations of the novel, published respectively by Penguin and The New American Library of World Literature. In 1976, Ralph Matlaw thoroughly revised Garnett's work for his Norton Critical Edition volume. This in turn was the basis for Victor Terras' influential *A Karamazov Companion*. Another translation is by Julius Katzer, published by Progress Publishers in 1981 and later re-printed by Raduga Publishers Moscow.

In 1990 Richard Pevear and Larissa Volokhonsky released a new translation; it won a PEN/Book-of-the-Month Club Translation Prize in 1991 and garnered positive reviews from *The New York Times Book Review* and the Dostoevsky scholar Joseph Frank, who praised it for being the most faithful to Dostoevsky's original Russian.

### Peter France

In *The Oxford Guide to Literature in English Translations*, academic Peter France comments on several translations of Dostoevsky's work.

In regard to Constance Garnett's translations, he writes:

> [Her] translations read easily...the basic meaning of the Russian text is accurately rendered on the whole. It is true, as critics such as Nikoliukin have demonstrated, that she shortens and simplifies, muting Dostoevsky's jarring contrasts, sacrificing his insistent rhythms and repetitions, toning down the Russian colouring, explaining and normalizing in all kinds of ways...Garnett shortens some of Dostoevsky's idiosyncrasy in order to produce an acceptable English text, but her versions were in many cases pioneering versions; decorous they may be, but they allowed this strange new voice to invade English literature and thus made it possible for later translators to go further in the search for more authentic voice.

On David Magarshack's Dostoevsky translations, France says:

> [I]t is not certain that Magarshack has worn as well as Garnett. He certainly corrects some of her errors; he also aims for a more up-to-date style which flows more easily in English...Being even more thoroughly englished than Garnett's, Magarshack's translations lack some of the excitement of the foreign.

On Andrew R. MacAndrew's American version, he comments: "He translates fairly freely, altering details, rearranging, shortening and explaining the Russian to produce texts which lack a distinctive voice."

On David McDuff's Penguin translation:

> McDuff carries this literalism the furthest of any of the translators. In his *Brothers Karamazov* the odd, fussy tone of the narrator is well rendered in the preface...At times, indeed, the convoluted style might make the reader unfamiliar with Dostoevsky's Russian question the translator's command of English. More seriously, this literalism means that the dialogue is sometimes impossibly odd—and as a result rather dead...Such 'foreignizing' fidelity makes for difficult reading.

On Pevear and Volokhonsky's translation, France writes:

> Pevear and Volokhonsky, while they too stress the need to exhume the real, rough-edged Dostoevsky from the normalization practised by earlier translators, generally offer a rather more satisfactory compromise between the literal and the readable. In particular, their rendering of dialogue is often livelier and more colloquial than McDuff's...Elsewhere, it has to be said, the desire to replicate the vocabulary or syntax of the Russian results in unnecessary awkwardness and obscurity.

In commenting on Ignat Avsey's translation, he writes: "His not entirely unprecedented choice of a more natural-sounding English formulation is symptomatic of his general desire to make his text English...His is an enjoyable version in the domesticating tradition."

### List of English translations

This is a list of all unabridged and one abridged English translations of the novel:

1. Constance Garnett (1912)
 1. revised by Avrahm Yarmolinsky (1933)
 2. revised by Alexandra Kropotkin and abridged by W. Somerset Maugham (1949)
 3. revised by Manuel Komroff (1958)
 4. revised by Ralph E. Matlaw (1976)
 5. revised by Ralph E. Matlaw and Susan McReynolds Oddo (2011)
2. David Magarshack (1958)
3. Andrew R. MacAndrew (1970)
4. Julius Katzer (1980, as *The Karamazov Brothers*)
5. Richard Pevear and Larissa Volokhonsky (1990)
6. David McDuff (1993)
7. Ignat Avsey (1994, as *The Karamazov Brothers*)
8. Michael R. Katz (2023)

## Adaptations

### Film

There have been several film adaptations of *The Brothers Karamazov*, including:

- *The Brothers Karamazov* (1915 silent film, lost, directed by Victor Tourjansky)
- *Die Brüder Karamasoff* (1921, directed by Carl Froelich, in German)
- *Der Mörder Dimitri Karamasoff* (1931, directed by Erich Engels & Fyodor Otsep, in German)
- *I fratelli Karamazoff* (1947, directed by Giacomo Gentilomo, in Italian)
- *The Brothers Karamazov* (1958, directed by Richard Brooks)
- *The Brothers Karamazov* (1969, directed by Kirill Lavrov, Ivan Pyryev and Mikhail Ulyanov)
- *The Brothers Karamazov* (1969, directed by Marcel Bluwal)
- *The Enemy Brothers* (1974, Egypt)

### Television

A Russian 12-episode series was produced in 2009 and is considered to be as close to the book as possible. It aired on Channel One.

The 2013 Japanese TV drama *Karamazov no Kyōdai* is an adaptation of the book set in modern-day Japan.

The Open University produced a version of "The Grand Inquisitor" in 1975 starring John Gielgud.

"The Grand Inquisitor" was adapted for British television as a one-hour drama titled *Inquisition*. Starring Derek Jacobi as the inquisitor, it was first broadcast on Channel 5 on 22 December 2002.

A 30-episode drama series named *Oulad El Moukhtar* ('Mokhtar's Sons') was produced by Nabil Ayouch for Al Aoula in 2020. The adaptation of the book is set in Morocco, with some aspects changed to resemble the local Moroccan culture.

### Radio

BBC Radio aired an adaptation (which omits the Grand Inquisitor episode) starring Roy Marsden, Paul Hilton, Nicholas Boulton and Carl Prekopp in 2006.

## Unfinished sequel

A sequel to *The Brothers Karamazov* that would detail the life of Alexey Karamazov beyond the ending of what was supposed to be the first novel had been planned out by Dostoevsky, but was left unfinished due to the author's death in 1881. It would have included a plot that saw Alexey killing the Russian Tsar.
