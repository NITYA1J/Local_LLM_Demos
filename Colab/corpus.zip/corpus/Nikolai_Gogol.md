---
title: "Nikolai Gogol"
source: "https://en.wikipedia.org/wiki/Nikolai_Gogol"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Nikolai Gogol

Russian writer of Ukrainian origin (1809–1852)

**Nikolai Vasilyevich Gogol** (1 April [O.S. 20 March] 1809 – 4 March [O.S. 21 February] 1852) was a Russian novelist, short-story writer, and playwright of Ukrainian origin.

Gogol used the grotesque in his writings, for example in his works "The Nose", "Viy", "The Overcoat", and "Nevsky Prospekt". These stories, and others such as "Diary of a Madman", have also been noted for their proto-surrealist qualities. According to Viktor Shklovsky, Gogol used the technique of defamiliarization, whereby a writer presents common things in an unfamiliar or strange way so that the reader can gain new perspectives and see the world differently. His early works, such as *Evenings on a Farm Near Dikanka*, were influenced by his Ukrainian upbringing, Ukrainian culture and folklore. His later writing satirised political corruption in contemporary Russia (*The Government Inspector*, *Dead Souls*), although Gogol also enjoyed the patronage of Tsar Nicholas I, who liked his work. The novel *Taras Bulba* (1835), the play *Marriage* (1842), and the short stories "The Tale of How Ivan Ivanovich Quarreled with Ivan Nikiforovich", "The Portrait", and "The Carriage" are also among his best-known works.

Many writers and critics have recognized Gogol's deep influence on Russian, Ukrainian and world literature. Gogol's influence was acknowledged by Fyodor Dostoevsky, Mikhail Saltykov-Shchedrin, Ryūnosuke Akutagawa, Franz Kafka, Mikhail Bulgakov, Vladimir Nabokov, Flannery O'Connor and others. Eugène-Melchior de Vogüé said: "We all came out from under Gogol's Overcoat."

## Early life

Gogol was born in the Ukrainian Cossack town of Sorochyntsi, in the Poltava Governorate of the Russian Empire. His mother was descended from Leonty Kosyarovsky, an officer of the Lubny Regiment in 1710. His father Vasily Gogol-Yanovsky, who died when Gogol was 15 years old, was supposedly a descendant of Ukrainian Cossacks (see Lyzohub family) and belonged to the class of *pomeshchiks*: he owned the village of Vasylivka, now Hoholeve [uk]. Gogol knew that his paternal ancestor Ostap Hohol [uk], a Cossack hetman in Polish service, received nobility from the Polish king. The family used the Polish surname "Janowski" (Ianovskii) and the family estate in Vasilevka was known as Ianovshchyna.

His father wrote poetry in Ukrainian as well as Russian, and was an amateur playwright in his own theatre. As was typical of the left-bank Ukrainian gentry of the early nineteenth century, the family was trilingual, speaking Ukrainian as well as Russian, and using Polish mostly for reading. Gogol's mother called her son Nikola, which is a mixture of the Russian Nikolai and the Ukrainian Mykola. As a child, Gogol helped stage plays in his uncle's home theater.

In 1820, Nikolai Gogol went to a school of higher art in Nezhin (Nizhyn) (now Nizhyn Gogol State University) and remained there until 1828. It was there that he began writing. He was not popular among his schoolmates, who called him their "mysterious dwarf", but he formed lasting friendships with two or three of them. Very early he developed a dark and secretive disposition, marked by a painful self-consciousness and boundless ambition. Equally early he developed a talent for mimicry, which later made him a matchless reader of his own works and induced him to toy with the idea of becoming an actor.

On leaving school in 1828, Gogol went to Saint Petersburg, full of vague but ambitious hopes. He desired literary fame, and brought with him a Romantic poem of German idyllic life – *Hans Küchelgarten*, and had it published at his own expense, under the pseudonym "V. Alov." The magazines he sent it to almost universally derided it. He bought all the copies and destroyed them, swearing never to write poetry again.

## Literary development

Cover of the first edition of *The Government Inspector* (1836)

His stay in St. Petersburg forced Gogol to make a certain decision regarding his self-identification. It was a period of turmoil; the November Uprising in the lands of the former Polish-Lithuanian Commonwealth led to a rise of Russian nationalism. Initially, Gogol used the surname Gogol-Ianovskii, but it soon became inconvenient. At first he tried to shorten it to the Russian-sounding "Ianov", but in the second half of 1830 he abandoned the Polish part of his surname altogether. He even admonished his mother in a letter to address him only as "Gogol", as Poles had become "suspect" in St. Petersburg. Tsarist authorities encouraged the Ukrainian intellectuals to sever ties with the Poles, promoting a limited, folkloric Ukrainian particularism as part of the heritage of the Russian empire.

In 1831, the first volume of Gogol's Ukrainian stories (*Evenings on a Farm Near Dikanka*) was published under a pen name "Rudy Panko", was in line with this trend, and met with immediate success. A second volume was published in 1832, followed by two volumes of stories entitled *Mirgorod* in 1835, and two volumes of miscellaneous prose entitled *Arabesques*. Although Gogol wrote in Russian, Russian editors and critics of that time such as Nikolai Polevoy and Nikolai Nadezhdin saw Gogol as a regional Ukrainian writer, and used his works to illustrate the specific of Ukrainian national characters. In 1981, literary scholar George Grabowicz argues that Ukrainian literature of Gogol's times was multilingual, with Ukrainian writers using Polish and Russian alongside Ukrainian. Therefore Gogol should be understood as both Russian and Ukrainian writer, especially in his early writings.

The themes and style of these early prose works by Gogol, as well as his later drama, were similar to the work of Ukrainian-language writers and dramatists who were his contemporaries and friends, including Hryhory Kvitka-Osnovyanenko. However, Gogol's satire was much more sophisticated and unconventional. Although these works were written in Russian, they were nevertheless full of Ukrainianisms, which is why a glossary of Ukrainian words was included at the end of the volumes.

At this time, Gogol developed a passion for Ukrainian Cossack history and tried to obtain an appointment to the history department at Saint Vladimir Imperial University of Kiev. Despite the support of Alexander Pushkin and Sergey Uvarov, the Russian minister of education, the appointment was blocked by a bureaucrat on the grounds that Gogol was unqualified. His fictional story *Taras Bulba*, based on the history of Zaporozhian Сossacks, was the result of this phase in his interests. During this time, he also developed a close and lifelong friendship with the historian and naturalist Mykhaylo Maksymovych.

In 1834, Gogol was made Professor of Medieval History at the University of St. Petersburg, a job for which he had no qualifications. The academic venture proved a disaster:

> He turned in a performance ludicrous enough to warrant satiric treatment in one of his own stories. After an introductory lecture made up of brilliant generalizations which the 'historian' had prudently prepared and memorized, he gave up all pretence at erudition and teaching, missed two lectures out of three, and when he did appear, muttered unintelligibly through his teeth. At the final examination, he sat in utter silence with a black handkerchief wrapped around his head, simulating a toothache, while another professor interrogated the students.

Gogol resigned his chair in 1835.

Commemorative plaque on his house in Rome

Between 1832 and 1836, Gogol worked with great energy, and had extensive contact with Pushkin, but he still had not yet decided that his ambitions were to be fulfilled by success in literature. During this time, the Russian critics Stepan Shevyrev and Vissarion Belinsky, contradicting the earlier critics, reclassified Gogol from a Ukrainian to a Russian writer. It was only after the premiere of his comedy *The Government Inspector* (*Revizor*) at the Alexandrinsky Theatre in St. Petersburg, on 19 April 1836, that he finally came to believe in his literary vocation. The comedy, a satire of Russian provincial bureaucracy, was staged thanks only to the intervention of the emperor, Nicholas I. The Tsar was personally present at the play's premiere, concluding that "there is nothing sinister in the comedy, as it is only a cheerful mockery of bad provincial officials."

From 1836 to 1848, Gogol lived abroad, travelling through Germany and Switzerland. Gogol spent the winter of 1836–37 in Paris, among Russian expatriates and Polish exiles, frequently meeting the Polish poets Adam Mickiewicz and Bohdan Zaleski. He eventually settled in Rome. For much of the twelve years from 1836, Gogol was in Italy, where he developed an adoration for Rome. He studied art, read Italian literature and developed a passion for opera.

Pushkin's death produced a strong impression on Gogol. His principal work during the years following Pushkin's death was the satirical epic *Dead Souls*. Concurrently, he worked at other tasks – recast *Taras Bulba* (1842) and *The Portrait*, completed his second comedy, *Marriage* (*Zhenitba*), wrote the fragment *Rome* and his most famous short story, "The Overcoat".

In 1841, the first part of *Dead Souls* was ready, and Gogol took it to Russia to supervise its printing. It appeared in Moscow in 1842, under a new title imposed by the censorship, *The Adventures of Chichikov*. The book established his reputation as one of the greatest prose writers in the language.

## Later life

One of several portraits of Gogol by Fyodor Moller (1840)

After the triumph of *Dead Souls*, Gogol's contemporaries came to regard him as a great satirist who lampooned the unseemly sides of Imperial Russia. They did not know that *Dead Souls* was but the first part of a planned modern-day counterpart to the *Divine Comedy* of Dante. The first part represented the *Inferno*; the second part would depict the gradual purification and transformation of the rogue Chichikov under the influence of virtuous publicans and governors – *Purgatory*.

In April 1848, Gogol returned to Russia from a pilgrimage to Jerusalem and passed his last years in restless movement throughout the country. While visiting the capitals, he stayed with friends such as Mikhail Pogodin and Sergey Aksakov. During this period, he also spent much time with his old Ukrainian friends, Maksymovych and Osyp Bodiansky. He intensified his relationship with a starets or spiritual elder, Matvey Konstantinovsky, whom he had known for several years. Konstantinovsky seems to have strengthened in Gogol the fear of perdition (damnation) by insisting on the sinfulness of all his imaginative work.

## Death

Exaggerated ascetic practices undermined his health and he became deeply depressed. On the night of 24 February 1852, he burned some of his manuscripts, which contained most of the second part of *Dead Souls*. He explained this as a mistake, a practical joke played on him by the Devil. Soon thereafter, he took to bed, refused all food, and died in great pain nine days later.

Gogol was mourned in the Saint Tatiana church at the Moscow University before his burial and then buried at the Danilov Monastery, close to his fellow Slavophile Aleksey Khomyakov. His grave was marked by a large stone (Golgotha), topped by a Russian Orthodox cross.

Gogol's grave at the Novodevichy Cemetery, as it looked in 1952–2009

The original design of the gravesite was restored in 2009. Novodevichy Cemetery, Moscow, Russia.

In 1931, with Russia now ruled by communists, Moscow authorities decided to demolish the monastery and had Gogol's remains transferred to the Novodevichy Cemetery. His body was discovered lying face down, which gave rise to the conspiracy theory that Gogol had been buried alive. The authorities moved the Golgotha stone to the new gravesite, but removed the cross; in 1952, the Soviets replaced the stone with a bust of Gogol. The stone was later reused for the tomb of Gogol's admirer Mikhail Bulgakov. In 2009, in connection with the bicentennial of Gogol's birth, the bust was moved to the museum at the Novodevichy Cemetery, and the original Golgotha stone was returned, along with a copy of the original Orthodox cross.

The first Gogol monument in Moscow, a Symbolist statue on Arbat Square, represented the sculptor Nikolay Andreyev's idea of Gogol rather than the real man. Unveiled in 1909, the statue received praise from Ilya Repin and from Leo Tolstoy as an outstanding projection of Gogol's tortured personality. Everything changed after the October Revolution. Joseph Stalin did not like the statue, and it was replaced by a more orthodox Socialist Realist monument in 1952. It took enormous efforts to save Andreyev's original work from destruction; as of 2014 it stood in front of the house where Gogol died.

## Style

Among the illustrators of *Dead Souls* was Pyotr Sokolov.

D. S. Mirsky characterizes Gogol's universe as "one of the most marvellous, unexpected – in the strictest sense, original – worlds ever created by an artist of words".

Gogol saw the outer world strangely metamorphosed, a singular gift particularly evident from the fantastic spatial transformations in his Gothic stories, "A Terrible Vengeance" and "A Bewitched Place". His pictures of nature are strange mounds of detail heaped on detail, resulting in an unconnected chaos of things: "His people are caricatures, drawn with the method of the caricaturist – which is to exaggerate salient features and to reduce them to geometrical pattern. But these cartoons have a convincingness, a truthfulness, and inevitability – attained as a rule by slight but definitive strokes of unexpected reality – that seems to beggar the visible world itself." According to Andrey Bely, Gogol's work influenced the emergence of Gothic romance, and served as a forerunner for absurdism and impressionism.

The aspect under which the mature Gogol sees reality is expressed by the Russian word *poshlost'*, which means something similar to "triviality, banality, inferiority", moral and spiritual, widespread in a group of people or the entire society. Like Sterne before him, Gogol was a great destroyer of prohibitions and of romantic illusions. He undermined Russian Romanticism by making vulgarity reign where only the sublime and the beautiful had before. "Characteristic of Gogol is a sense of boundless superfluity that is soon revealed as utter emptiness and a rich comedy that suddenly turns into metaphysical horror." His stories often interweave pathos and mockery, while "The Tale of How Ivan Ivanovich Quarreled with Ivan Nikiforovich" begins as a merry farce and ends with the famous dictum "It is dull in this world, gentlemen!"

## Politics

The first Gogol memorial in Russia (an impressionistic statue by Nikolay Andreyev, 1909)

A more conventional statue of Gogol at the Villa Borghese gardens, Rome

*Gogol burning the manuscript of the second part of* Dead Souls, by Ilya Repin

Postage stamp, Russia, 2009

It stunned Gogol when some critics interpreted *The Government Inspector* as an indictment of Tsarism despite Nicholas I's patronage of the play. Gogol himself, an adherent of the Slavophile movement, believed in a divinely inspired mission for both the House of Romanov and the Russian Orthodox Church. Like Fyodor Dostoyevsky, Gogol sharply disagreed with those Russians who preached constitutional monarchy and the disestablishment of the Orthodox Church. Gogol saw his work as a critique that would change Russia for the better.

After defending autocracy, serfdom, and the Orthodox Church in his book *Selected Passages from Correspondence with his Friends* (1847), Gogol came under attack from his former patron Vissarion Belinsky. The first Russian intellectual to publicly preach the economic theories of Karl Marx, Belinsky accused Gogol of betraying his readership by defending the *status quo*.

## National identity

Gogol was born in the Ukrainian Cossack town of Sorochyntsi. According to Edyta Bojanowska, Gogol's images of Ukraine are in-depth, distinguished by description of folklore and history. In his *Evenings on a Farm*, Gogol pictures Ukraine as a "nation... united by organic culture, historical memory, and language". His image of Russia lacks this depth and is always based in the present, particularly focused on Russia's bureaucracy and corruption. *Dead Souls*, according to Bojanowska, "presents Russian uniqueness as a catalog of faults and vices." The duality of Gogol’s national identity is frequently expressed as a view that "in the aesthetic, psychological, and existential senses Gogol is inscribed... into Ukrainian culture", while "in historical and cultural terms he is part of Russian literature and culture". Slavicist Edyta Bojanowska writes that Gogol, after arriving in St. Petersburg, was surprised to find that he was perceived as a Ukrainian, and even as a *khokhol* (hick). Bojanowska argues that it was this experience that "made him into a *self-conscious Ukrainian*". According to Ilchuk, dual national identities were typical at that time as a "compromise with the empire's demand for national homogenization".

Professor of Russian literature Kathleen Scollins notes the tendency to politicize Gogol's identity, and comments on the erasure of Gogol's Ukrainianness by the Russian literary establishment, which she argues "reveals the insecurity of many Russians about their own imperial identity". According to Scollins, Gogol's narrative double-voicedness in both *Evenings* and *Taras Bulba* and "pidginized Russian" of the Zaporizhian Cossacks in "The Night before Christmas represents a "strateg[y] of resistance, self-assertion, and divergence"". Linguist Daniel Green notes "the complexities of an imperial culture in which Russian and Ukrainian literatures and identities informed and shaped each other, with Gogol´ playing a key role in these processes".

Gogol's appreciation of Ukraine grew during his discovery of Ukrainian history, and he concluded that "Ukraine possessed exactly the kind of cultural wholeness, proud tradition, and self-awareness that Russia lacked." He rejected or was critical of many of the postulates of official Russian history about Ukrainian nationhood. His unpublished "Mazepa’s Meditations" presents Ukrainian history in a manner that justifies Ukraine’s "historic right to independence". Before 1836, Gogol had planned to move to Kyiv to study Ukrainian ethnography and history, and it was after these plans failed that he decided to become a Russian writer.

Professor of literature and Gogol researcher Oleh Ilnytzkyj also argues against the traditional classification of Nikolai Gogol as a Russian writer, saying that he should be viewed as a Ukrainian writer operating within an imperial culture. The "Russian" view of Gogol, he contends, arises from "all-Russianness," an ideology aimed at assimilating the East Slavs into a singular "Russian" nation. Gogol was appropriated by an underdeveloped Russian literature, which downplayed his Ukrainian heritage and nationalism to bolster its own prestige. Ilnytzkyj emphasizes that Russian functioned as an imperial lingua franca rather than a marker of nationality, serving as a literary language adopted by Ukrainian society to advance a Ukrainian national agenda before Ukrainian became the preferred option. He refutes the notion that Gogol’s Ukrainian and Russian works reflect a "divided soul," portraying them instead as unified expressions of Ukrainian nationalism—rooted in a deep love for Ukraine and disdain for Russia, from which he self-exiled for twelve years. Gogol’s struggle, Ilnytzkyj argues, was not with his identity but with the demands placed on him by Russian imperial expectations.

In his interpretation of Taras Bulba (1842), Ilnytzkyj argues that the second edition of the novel is a profound assertion of Ukrainian nationalism, supported by a meticulous examination of Gogol’s use of terms such as russkii, Rossiia, and tsar'. According to Ilnytzkyj, Gogol deliberately linked his Ukrainian Cossack characters to the legacy of Kyivan Rus’, crafting a distinct Ukrainian-Rus’ian identity with the term russkii—a direct challenge to the "all-Russian" narrative advanced by Russian imperial ideology. While Gogol’s legacy occupies a place in both Ukrainian and Russian literary traditions, Ilnytzkyj cautions against confusing his dual influence with a hyphenated identity, emphasizing instead Gogol’s fundamental Ukrainian identity within a transnational imperial framework. Finally, Ilnytzkyj asserts that nothing Gogol wrote after 1842 undermines his identity as a Ukrainian writer. After publishing Dead Souls and the revised Taras Bulba, Gogol ceased to function as an artist, despite attempts to sustain his earlier creative efforts. His later non-fiction, shaped by a religious crisis and pressure to revise his views on Russia, cannot negate the Ukrainian nationalist and anti-Russian achievements of his earlier fiction.

## Influence and interpretations

Even before the publication of *Dead Souls*, Belinsky recognized Gogol as the first Russian-language realist writer and as the head of the natural school, to which he also assigned younger or lesser authors such as Goncharov, Turgenev, Dmitry Grigorovich, Vladimir Dahl and Vladimir Sollogub. Gogol himself appeared skeptical about the existence of such a literary movement. Although he recognized "several young writers" who "have shown a particular desire to observe real life", he upbraided the deficient composition and style of their works. Nevertheless, subsequent generations of radical critics celebrated Gogol (the author in whose world a nose roams the streets of the Russian capital) as a great realist, a reputation decried by the *Encyclopædia Britannica* as "the triumph of Gogolesque irony".

The period of literary modernism saw a revival of interest in and a change of attitude towards Gogol's work. One of the pioneering works of Russian formalism was Eichenbaum's reappraisal of "The Overcoat". In the 1920s, a group of Russian short-story writers, known as the Serapion Brothers, placed Gogol among their precursors and consciously sought to imitate his techniques. The leading novelists of the period – notably Yevgeny Zamyatin and Mikhail Bulgakov – also admired Gogol and followed in his footsteps. In 1926, Vsevolod Meyerhold staged *The Government Inspector* as a "comedy of the absurd situation", revealing to his fascinated spectators a corrupt world of endless self-deception. In 1934, Andrei Bely published the most meticulous study of Gogol's literary techniques up to that date, in which he analyzed the colours prevalent in Gogol's work depending on the period, his impressionistic use of verbs, the expressive discontinuity of his syntax, the complicated rhythmical patterns of his sentences, and many other secrets of his craft. Based on this work, Vladimir Nabokov published a summary account of Gogol's masterpieces.

The house in Moscow where Gogol died. The building contains the fireplace where he burned the manuscript of the second part of *Dead Souls*.

Gogol's impact on Russian literature has endured, yet various critics have appreciated his works differently. Belinsky, for instance, berated his horror stories as "moribund, monstrous works", while Andrei Bely counted them among his most stylistically daring creations. Nabokov especially admired *Dead Souls*, *The Government Inspector*, and "The Overcoat" as works of genius, proclaiming that "when, as in his immortal 'The Overcoat', Gogol really let himself go and pottered happily on the brink of his private abyss, he became the greatest artist that Russia has yet produced." Critics traditionally interpreted "The Overcoat" as a masterpiece of "humanitarian realism", but Nabokov and some other attentive readers argued that "holes in the language" make the story susceptible to interpretation as a supernatural tale about a ghostly double of a "small man". Of all Gogol's stories, "The Nose" has stubbornly defied all abstruse interpretations: D.S. Mirsky declared it "a piece of sheer play, almost sheer nonsense". In recent years, however, "The Nose" has become the subject of several postmodernist and postcolonial interpretations.

The portrayals of Jewish characters in his work have led to Gogol developing a reputation for antisemitism. Due to these portrayals, the Russian Zionist writer Ze'ev Jabotinsky condemned Russian Jews who participated in celebrations of Gogol's centenary. Later critics have also pointed to the apparent antisemitism in his writings, as well as in those of his contemporary, Fyodor Dostoyevsky. Felix Dreizin and David Guaspari, for example, in their *The Russian Soul and the Jew: Essays in Literary Ethnocentrism*, discuss "the significance of the Jewish characters and the negative image of the Ukrainian Jewish community in Gogol's novel *Taras Bulba*, pointing out Gogol's attachment to anti-Jewish prejudices prevalent in Russian and Ukrainian culture." In Léon Poliakov's *The History of Antisemitism*, the author mentions that

> "The 'Yankel' from *Taras Bulba* indeed became the archetypal Jew in Russian literature. Gogol painted him as supremely exploitative, cowardly, and repulsive, albeit capable of gratitude. But it seems perfectly natural in the story that he and his cohorts be drowned in the Dniper by the Cossack lords. Above all, Yankel is ridiculous, and the image of the plucked chicken that Gogol used has made the rounds of great Russian authors."

Despite his portrayal of Jewish characters, Gogol left a powerful impression even on Jewish writers who inherited his literary legacy. Amelia Glaser has noted the influence of Gogol's literary innovations on Sholem Aleichem, who

> "chose to model much of his writing, and even his appearance, on Gogol... What Sholem Aleichem was borrowing from Gogol was a rural East European landscape that may have been dangerous, but could unite readers through the power of collective memory. He also learned from Gogol to soften this danger through laughter, and he often rewrites Gogol's Jewish characters, correcting anti-Semitic stereotypes and narrating history from a Jewish perspective."

### In music and film

Gogol's oeuvre has also had an impact on Russia's non-literary culture, and his stories have been adapted numerous times into opera and film. The Russian composer Alfred Schnittke wrote the eight-part *Gogol Suite* as incidental music to *The Government Inspector* performed as a play, and Dmitri Shostakovich set *The Nose* as his first opera in 1928 – a peculiar choice of subject for what was meant to initiate the great tradition of Soviet opera. More recently, to celebrate the 200th anniversary of Gogol's birth in 1809, Vienna's renowned Theater an der Wien commissioned music and libretto for a full-length opera on the life of Gogol from Russian composer and writer Lera Auerbach.

More than 135 films have been based on Gogol's work, the most recent being *The Girl in the White Coat* (2011).

## Legacy

Gogol has been featured many times on Russian and Soviet postage stamps; he is also well represented on stamps worldwide. Several commemorative coins have been issued in the USSR and Russia. In 2009, the National Bank of Ukraine issued a commemorative coin dedicated to Gogol. Streets have been named after Gogol in various cities, including Moscow, Sofia, Lipetsk, Odesa, Myrhorod, Krasnodar, Vladimir, Vladivostok, Penza, Petrozavodsk, Riga, Bratislava, Belgrade, Harbin and many other towns and cities.

Gogol is mentioned several times in Fyodor Dostoyevsky's *Poor Folk* and *Crime and Punishment* and Chekhov's *The Seagull*.

Ryūnosuke Akutagawa considered Gogol along with Edgar Allan Poe his favorite writers.

## Adaptations

BBC Radio 4 made a series of six Gogol short stories, entitled *Three Ivans, Two Aunts and an Overcoat* (2002, adaptations by Jim Poyser) starring Griff Rhys-Jones and Stephen Moore. The stories adapted were "The Two Ivans", "The Overcoat", "Ivan Fyodorovich Shponka and His Aunt", "The Nose", "The Mysterious Portrait" and "Diary of a Madman".

Gogol's short story "Christmas Eve" (literally the Russian title «Ночь перед Рождеством» translates as "The Night before Christmas") was adapted into operatic form by at least three East Slavic composers. Ukrainian composer Mykola Lysenko wrote his *Christmas Eve* («Різдвяна ніч», with libretto in Ukrainian by Mykhailo Starytsky) in 1872. Just two years later, in 1874, Tchaikovsky composed his version under the title *Vakula the Smith* (with Russian libretto by Yakov Polonsky) and revised it in 1885 as *Cherevichki (The Tsarina's Slippers)*. In 1894 (i.e., just after Tchaikovsky's death), Rimsky-Korsakov wrote the libretto and music for his own opera based on the same story. "Christmas Eve" was also adapted into a film in 1961 entitled The Night Before Christmas. It was adapted also for radio by Adam Beeson and broadcast on BBC Radio 4 on 24 December 2008 and subsequently rebroadcast on both Radio 4 and Radio 4 Extra on Christmas Eve 2010, 2011 and 2015.

Gogol's story "Viy" was adapted into film by Russian filmmakers four times: the original *Viy* in 1967; the horror film *Vedma* (aka *The Power of Fear*) in 2006; the action-horror film *Viy* in 2014; and the horror film *Gogol Viy*, released in 2018. It was also adapted into the Russian full-motion video game *Viy: The Story Retold* (2004). Outside of Russia, the film loosely served as the inspiration for Mario Bava's 1960 film *Black Sunday* and the 2008 South Korean horror film *Evil Spirit ; VIY*.

In 2016, Gogol's short story "The Portrait" was announced to be adapted into a feature film of the same name, by Anastasia Elena Baranoff and Elena Vladimir Baranoff.

The Russian TV-3 television series *Gogol* features him as a lead character and presents a fictionalized version of his life that mixes his history with elements from his various stories. The episodes were also released theatrically starting with *Gogol. The Beginning* in August 2017. A sequel entitled *Gogol. Viy* was released in April 2018, and the third film, *Gogol. Terrible Revenge*, debuted in August 2018.

In 1963, an animated version of Gogol's classic surrealist story "The Nose" was made by Alexandre Alexeieff and Claire Parker, using the pinscreen animation technique, for the National Film Board of Canada. A definitive animated movie adaptation of the story was released in January 2020. Meanwhile, *The Nose or Conspiracy of Mavericks* has been in production for about fifty years.

## Bibliography
