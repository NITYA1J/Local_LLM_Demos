---
title: "Dead Souls"
source: "https://en.wikipedia.org/wiki/Dead_Souls"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Dead Souls

1842 novel by Nikolai Gogol

Dead Souls

***Dead Souls*** (Russian: Мёртвые души *Myórtvyye dúshi*, pre-reform spelling: Мертвыя души) is a novel by Nikolai Gogol, first published in 1842, and widely regarded as an exemplar of 19th-century Russian literature. The novel chronicles the travels and adventures of Pavel Ivanovich Chichikov and the people whom he encounters. These people typify the Russian middle aristocracy of the time. Gogol himself saw his work as an "epic poem in prose", and within the book characterised it as a "poem in prose". Gogol intended the novel to be the first part of a three-volume work, but burned the manuscript of the second part shortly before his death. Modern editions of *Dead Souls* include what survives from Part Two, as reconstructed by editors from Gogol's notebooks. Although the novel ends in mid-sentence (like Sterne's *Sentimental Journey*), it is regarded by some as complete in the extant form. The novel is a satire of 19th-century Russian bureaucracy.

## Characterization

The original title, as shown on the illustration (cover page), was "The Wanderings of Chichikov, or Dead Souls. *Poema*", which contracted to merely "Dead Souls". In the Russian Empire, before the emancipation of the serfs in 1861, landowners had the right to own serfs. Serfs were for most purposes considered the property of the landowner, who could buy, sell or mortgage them, as any other chattel. To count serfs (and people in general), the classifier "soul" was used: e.g., "six souls of serfs". The plot of the novel relies on "dead souls" (i.e., "dead serfs") which are still accounted for in property registers. On another level, the title refers to the "dead souls" of Gogol's characters, all of which represent different aspects of *poshlost* (a Russian noun rendered as "commonplace, vulgarity", moral and spiritual, with overtones of middle-class pretentiousness, fake significance and philistinism).

*Dead Souls* has been compared to Miguel Cervantes' *Don Quixote* and Charles Dickens' *The Pickwick Papers*. The plot for the novel was suggested by Gogol's friend Alexander Pushkin.

Early 20th century critics began to suggest the story contained elements that may have been inspired by *Inferno* of the *Divine Comedy*, but that idea has since diminished among scholars. "Gogol reveals to his readers an encompassing picture of the ailing social system in Russia after the unsuccessful French invasion. As in many of Gogol's short stories, the social criticism of *Dead Souls* is communicated primarily through absurd and hilarious satire." Unlike the short stories, however, *Dead Souls* was meant to offer solutions rather than simply point out problems. This grander scheme was largely unrealized at Gogol's death; the work was never completed, and it is primarily the earlier, darker part of the novel that is remembered.

In their studies of Gogol, Andrey Bely, D. S. Mirsky, Vladimir Nabokov, and other modernist critics rejected the commonly held view of *Dead Souls* as a reformist or satirical work. For instance, Nabokov regarded the plot of *Dead Souls* as unimportant and Gogol as a great writer whose works skirted the irrational and whose prose style combined superb descriptive power with a disregard for novelistic clichés. True, Chichikov displays a most extraordinary moral rot, but the whole idea of buying and selling dead souls is, to Nabokov, ridiculous on its face; therefore, the provincial setting of the novel is a most unsuitable backdrop for any of the progressive, reformist or Christian readings of the work.

Critics note that it contains elements of a picaresque novel.

Chichikov in the house of M-me Korobochka.

## Characters

Of all Gogol's creations, Chichikov stands out as the incarnation of the complacent *poshlost*. Other characters—the squires Chichikov visits on his shady business—include: Sobakevich, a strong, silent, economical man; Manilov, a sentimentalist with pursed lips; Mme. Korobochka, a widow; Nozdryov, a bully. Plyushkin, the miser, appears to transcend the *poshlost* archetype in that he is not complacent but miserable.

## Plot summary

### Book One

The story follows the exploits of Pavel Chichikov, a middle-aged gentleman of middling social class and means. Chichikov arrives in a small town and turns on the charm to woo key local officials and landowners. He reveals little about his life thus far, or his purpose, as he sets about carrying out his bizarre and mysterious plan to acquire "dead souls."

Chichikov and Nozdryov.

The government taxed landowners based on how many serfs (or "souls") they owned. This was determined by the census, which was conducted infrequently, so landowners were often paying taxes on serfs in the revision lists that were no longer living, thus "dead souls." It is these dead souls, existing only on paper, that Chichikov seeks to purchase from the landlords in the villages he visits, whom he tells he will relieve of a needless tax burden.

Although the townspeople Chichikov comes across are gross caricatures, they are not flat stereotypes by any means. Instead, each is neurotically individual, combining the official failings that Gogol typically satirizes (greed, corruption, paranoia) with a curious set of personal quirks.

Illustration by Alexander Agin: *The Simply Pleasant Lady* and *The Lady Who Is Pleasant In All Respects*

Setting off for the surrounding estates, Chichikov at first assumes that the ignorant provincials will be more than eager to give their dead souls up in exchange for a token payment. The task of collecting the rights to dead people proves difficult, however, due to the persistent greed, suspicion, and general distrust of the landowners. He still manages to acquire some 400 souls, swears the sellers to secrecy, and returns to the town to have the transactions recorded legally.

Back in the town, Chichikov continues to be treated like a prince among the petty officials, and a celebration is thrown in honour of his purchases. Very suddenly, however, rumors flare up that the serfs he bought are all dead, and that he was planning to elope with the Governor's daughter. In the confusion that ensues, the backwardness of the irrational, gossip-hungry townspeople is most delicately conveyed. Absurd suggestions come to light, such as the possibility that Chichikov is Napoleon in disguise or the notorious vigilante 'Captain Kopeikin'. The now disgraced traveller is immediately ostracized from the company he had been enjoying and has no choice but to flee the town.

Chichikov is revealed by the author to be a former mid-level government official fired for corruption and narrowly avoiding jail. His macabre mission to acquire "dead souls" is actually just another one of his "get rich quick" schemes. Once he acquires enough dead souls, he will take out an enormous loan against them and pocket the money.

### Book Two

In the novel's second part, Chichikov flees to another part of Russia and attempts to continue his venture. He tries to help the idle landowner Tentetnikov gain favor with General Betrishchev so that Tentetnikov may marry the general's daughter, Ulinka. To do this, Chichikov agrees to visit many of Betrishchev's relatives, beginning with Colonel Koshkaryov. From there Chichikov begins again to go from estate to estate, encountering eccentric and absurd characters all along the way. Eventually he purchases an estate from the destitute Khlobuyev, and somewhere in the missing chapters is arrested when he attempts to forge the will of Khlobuyev's rich aunt. He is pardoned thanks to the intervention of the kindly Mourazov but is forced to flee the village. The novel ends mid-sentence with the prince who arranged Chichikov's arrest giving a grand speech that rails against corruption in the Russian government.

## Adaptations

Mikhail Bulgakov adapted the novel for the stage for a production at the Moscow Art Theatre. The seminal theatre practitioner Constantin Stanislavski directed the play, which opened on 28 November 1932.

The extant sections of *Dead Souls* formed the basis for an opera in 1976 by Russian composer Rodion Shchedrin. In it Shchedrin captures the different townspeople with whom Chichikov deals in isolated musical episodes, each of which employs a different musical style to evoke the character's particular personality.

The novel was adapted for screen in 1984 by Mikhail Schweitzer as a television miniseries of the same name.

In 2006 the novel was dramatised for radio in two parts by the BBC and broadcast on Radio 4. It was played more for comic than satirical effect, the main comedy deriving from the performance of Mark Heap as Chichikov and from the original placing of the narrator. Michael Palin narrates the story, but is revealed actually to be following Chichikov, riding in his coach for example, or sleeping in the same bed, constantly irritating Chichikov with his running exposition.

The first UK theatre production was staged by Theatre Collection in London during November 2014, directed by Victor Sobchak and starring Garry Voss as Chichikov and Vera Horton as Korobochka.

Alex Cox directed and starred in a 2025 adaptation as a Western.

## English translations

- 1886: Isabel Hapgood
- 1916: C. J. Hogarth (sometimes printed as "D. J. Hogarth". Now in the public domain; introduction by John Cournos)
- 1922: Constance Garnett (published by Chatto & Windus, reissued in 2007 by Kessinger Publishing; introduction by Clifford Odets)
- 1942: Bernard Guilbert Guerney Archived 2022-04-19 at the Wayback Machine (published by the New York Readers' Club, revised 1948, and again by Susanne Fusso in 1996). Considered to be the best English version by Vladimir Nabokov, with the qualification that no later translations had yet been released at the time of his study in 1944.
- 1957: George Reavey (published by Oxford World's Classics, revised by George Gibian and reprinted in 1985 by W. W. Norton & Company as a critical edition with supplementary essays and criticism).
- 1961: David Magarshack (published by Penguin Classics).
- 1961: Andrew R. MacAndrew (published by The New American Library; foreword by Frank O'Connor). 
- 1996: Richard Pevear and Larissa Volokhonsky (published by Pantheon Books).
- 1998: Christopher English (published by Oxford World's Classics, reissued in 2009).
- 2004: Robert A. Maguire (published by Penguin Classics).
- 2008: Donald Rayfield (published by Garnett Press; reissued in 2012 by New York Review Books).
