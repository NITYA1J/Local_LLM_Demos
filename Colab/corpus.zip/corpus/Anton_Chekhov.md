---
title: "Anton Chekhov"
source: "https://en.wikipedia.org/wiki/Anton_Chekhov"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Anton Chekhov

Russian dramatist and author (1860–1904)

Portrait of Anton Chekhov by Isaac Levitan (1886)

**Anton Pavlovich Chekhov** (/ˈtʃɛkɒf/; Russian: Антон Павлович Чехов; 29 January [O.S. 17 January] 1860 – 15 July [O.S. 2 July] 1904) was a Russian playwright and short story writer. Widely considered one of the greatest writers of all time, his career as a playwright produced four classics, and his best short stories are held in high esteem by writers and critics. Along with Henrik Ibsen and August Strindberg, Chekhov is often referred to as one of the three seminal figures in the birth of early modernism in the theatre. Chekhov was a physician by profession. "Medicine is my lawful wife," he once said, "and literature is my mistress."

Chekhov renounced the theatre after the reception of *The Seagull* in 1896, but the play was revived to acclaim in 1898 by Konstantin Stanislavski's Moscow Art Theatre, which subsequently also produced Chekhov's *Uncle Vanya* and premiered his last two plays, *Three Sisters* and *The Cherry Orchard*. These four works present a challenge to the acting ensemble as well as to audiences, because in place of conventional action Chekhov offers a "theatre of mood" and a "submerged life in the text."

Chekhov began writing stories to earn money, but as his artistic ambition grew, he made formal innovations that influenced the evolution of the modern short story. He wrote that it is not the duty of writers to solve problems, but to correctly state them.

## Biography

Birth house of Anton Chekhov in Taganrog, Chekhova street, Russia

The Taganrog Boys Gymnasium in the late 19th century. The cross on top is no longer present.

### Childhood

Anton Pavlovich Chekhov was born on the feast day of St. Anthony the Great on 29 January [O.S. 17 January] 1860) in Taganrog, a commercial port city on the Sea of Azov – on Politseyskaya (Police) street, later renamed Chekhova street – in southern Russia. He was the third of six surviving children; he had two older brothers, Alexander and Nikolai, and three younger siblings, Ivan, Maria, and Mikhail. His father, Pavel Yegorovich Chekhov, the son of a former serf and his wife, was from the village Olkhovatka (Voronezh Governorate) and ran a grocery store. He was a director of the parish choir, a devout Orthodox Christian, and a physically abusive father. Pavel Chekhov has been seen by some historians as the model for his son's many portraits of hypocrisy. Chekhov's mother, Yevgeniya (Morozova), was an excellent storyteller who entertained the children with tales of her travels all over Russia with her cloth-merchant father. "Our talents we got from our father," Chekhov recalled, "but our soul from our mother."

Young Chekhov attended the Greek School in Taganrog and The Taganrog Boys Gymnasium (since renamed the Chekhov Gymnasium). There he was held back for a year at fifteen for failing an examination in Ancient Greek. He sang at the Greek Orthodox monastery in Taganrog and in his father's choirs. In a letter of 1892, he used the word "suffering" to describe his childhood and recalled:

> When my brothers and I used to stand in the middle of the church and sing the trio "May my prayer be exalted", or "The Archangel's Voice", everyone looked at us with emotion and envied our parents, but we at that moment felt like little convicts.

Later, in his adulthood, Chekhov criticized his brother Alexander's treatment of his wife and children by reminding him of their father Pavel's tyranny: "Let me ask you to recall that it was despotism and lying that ruined your mother's youth. Despotism and lying so mutilated our childhood that it's sickening and frightening to think about it. Remember the horror and disgust we felt in those times when Father threw a tantrum at dinner over too much salt in the soup and called Mother a fool."

In 1876, Chekhov's father Pavel was declared bankrupt after overextending his finances building a new house, having been cheated by a contractor named Mironov. To avoid debtor's prison he fled to Moscow, where his two eldest sons, Alexander and Nikolai, were attending university. The family lived in poverty in Moscow. Chekhov's mother was physically and emotionally broken by the experience.

Chekhov was left behind to sell the family's possessions and finish his education. He remained in Taganrog for three more years, boarding with a man by the name of Selivanov who, like Lopakhin in *The Cherry Orchard*, had bailed out the family for the price of their house. Chekhov had to pay for his own education, which he managed by private tutoring, catching and selling goldfinches, and selling short sketches to the newspapers, among other jobs. He sent every ruble he could spare to his family in Moscow, along with humorous letters to cheer them up.

As a teenager Chekhov fell in love with the Taganrog Theatre. He attended the theatre on a regular basis and became enchanted and inspired by productions of vaudevilles, Italian operas and popular comedies.

During that time, Chekhov read widely and analytically, including the works of Cervantes, Turgenev, Goncharov, and Schopenhauer, and wrote a full-length comic drama, *Fatherless*, which his brother Alexander dismissed as "an inexcusable though innocent fabrication." Chekhov also experienced a series of love affairs, one with the wife of a teacher. In 1879, Chekhov completed his schooling in Taganrog and moved in with his family in Moscow, having gained admission to the medical school at I.M. Sechenov First Moscow State Medical University.

### Early writings

Chekhov then assumed responsibility for the whole family. To support them and to pay his tuition fees, he wrote daily short, humorous sketches and vignettes of contemporary Russian life, many under pseudonyms such as "Antosha Chekhonte" (Антоша Чехонте) and "Man Without Spleen" (Человек без селезенки). His prodigious output gradually earned him a reputation as a satirical chronicler of Russian street life, and by 1882 he was writing for *Oskolki* (*Fragments*), owned by Nikolai Leykin, one of the leading publishers of the time. Chekhov's tone at this stage was harsher than that familiar from his mature fiction.

Portrait of young Chekhov in country clothes

Anton Chekhov (left) with brother Nikolai in 1882

Anton Chekhov in 1880s

In 1884, Chekhov qualified as a physician, which he considered his principal profession though he made little money from it and treated the poor free of charge.

In 1884 and 1885, Chekhov found himself coughing blood, and in 1886 the attacks worsened, but he would not admit his tuberculosis to his family or his friends. He confessed to Leykin, "I am afraid to submit myself to be sounded by my colleagues." He continued writing for weekly periodicals, earning enough money to move the family into progressively better accommodations.

Early in 1886 he was invited to write for one of the most popular papers in St. Petersburg, *Novoye Vremya* (*New Times*), owned and edited by the millionaire magnate Alexey Suvorin, who paid a rate per line double Leykin's and allowed Chekhov three times the space. Suvorin was to become a lifelong friend, perhaps Chekhov's closest.

Before long, Chekhov was attracting literary as well as popular attention. The sixty-four-year-old Dmitry Grigorovich, a celebrated Russian writer of the day, wrote to Chekhov after reading his short story "The Huntsman" that "You have *real* talent, a talent that places you in the front rank among writers in the new generation." He went on to advise Chekhov to slow down, write less, and concentrate on literary quality.

Chekhov replied that the letter had struck him "like a thunderbolt" and confessed, "I have written my stories the way reporters write up their notes about fires—mechanically, half-consciously, caring nothing about either the reader or myself." The admission may have done Chekhov a disservice, since early manuscripts reveal that he often wrote with extreme care, continually revising. Grigorovich's advice nevertheless inspired a more serious, artistic ambition in the twenty-six-year-old. In 1888, with a little string-pulling by Grigorovich, the short story collection *At Dusk* (*V Sumerkakh*) won Chekhov the coveted Pushkin Prize "for the best literary production distinguished by high artistic worth."

### Turning points

Chekhov's family and friends in 1890: (top row, left to right) Ivan, Alexander, father; (second row) Mariya Korniyeeva, Lika Mizinova, Masha, Mother, Seryozha Kiselev; (bottom row) Misha, Anton

In 1887, exhausted from overwork and ill health, Chekhov took a trip to Ukraine, which reawakened him to the beauty of the steppe. On his return, he began the novella-length short story "*The Steppe*", which he called "something rather odd and much too original", and which was eventually published in *Severny Vestnik* (*The Northern Herald*). In a narrative that drifts with the thought processes of the characters, Chekhov evokes a chaise journey across the steppe through the eyes of a young boy sent to live away from home, and his companions, a priest and a merchant. "The Steppe" has been called a "dictionary of Chekhov's poetics", and it represented a significant advance for Chekhov, exhibiting much of the quality of his mature fiction and winning him publication in a literary journal rather than a newspaper.

In autumn 1887, a theatre manager named Korsh commissioned Chekhov to write a play, the result being *Ivanov*, written in a fortnight and produced that November. Though Chekhov found the experience "sickening" and painted a comic portrait of the chaotic production in a letter to his brother Alexander, the play was a hit and was praised, to Chekhov's bemusement, as a work of originality.

Although Chekhov did not fully realise it at the time, Chekhov's plays, such as *The Seagull* (written in 1895), *Uncle Vanya* (written in 1897), *The Three Sisters* (written in 1900), and *The Cherry Orchard* (written in 1903) served as a revolutionary backbone to what is common sense to the medium of acting to this day: an effort to recreate and express the realism of how people truly act and speak with each other. This realistic manifestation of the human condition may engender in audiences reflection upon what it means to be human.

This philosophy of approaching the art of acting has stood not only steadfast, but as the cornerstone of acting for much of the 20th century to this day. Mikhail Chekhov considered *Ivanov* a key moment in his brother's intellectual development and literary career. From this period comes an observation of Chekhov's that has become known as *Chekhov's gun*, a dramatic principle that requires that every element in a narrative be necessary and irreplaceable, and that everything else be removed.

> Remove everything that has no relevance to the story. If you say in the first chapter that there is a rifle hanging on the wall, in the second or third chapter it absolutely must go off. If it's not going to be fired, it shouldn't be hanging there.

— Anton Chekhov

The death of Chekhov's brother Nikolai from tuberculosis in 1889 influenced *A Dreary Story*, finished that September, about a man who confronts the end of a life that he realises has been without purpose. Mikhail Chekhov recorded his brother's depression and restlessness after Nikolai's death. Mikhail was researching prisons at that time as part of his law studies. Anton Chekhov, in a search for purpose in his own life, himself soon became obsessed with the issue of prison reform.

### Sakhalin

Anton Chekhov in 1893

In 1890, Chekhov undertook an arduous journey by train, horse-drawn carriage, and river steamer across Siberia to the Russian Far East and the *katorga* (penal colony) on Sakhalin Island, north of Japan. He spent three months there interviewing thousands of convicts and settlers for a census. The letters Chekhov wrote during the two-and-a-half-month journey to Sakhalin are considered among his best. His remarks to his sister about Tomsk were to become notorious.

> Tomsk is a very dull town. To judge from the drunkards whose acquaintance I have made, and from the intellectual people who have come to the hotel to pay their respects to me, the inhabitants are very dull, too.

Chekhov witnessed much on Sakhalin that shocked and angered him, including floggings, embezzlement of supplies, and forced prostitution of women. He wrote, "There were times I felt that I saw before me the extreme limits of man's degradation." He was particularly moved by the plight of the children living in the penal colony with their parents. For example:

> On the Amur steamer going to Sakhalin, there was a convict who had murdered his wife and wore fetters on his legs. His daughter, a little girl of six, was with him. I noticed wherever the convict moved the little girl scrambled after him, holding on to his fetters. At night the child slept with the convicts and soldiers all in a heap together.

Chekhov later concluded that charity was not the answer, but that the government had a duty to finance humane treatment of the convicts. His findings were published in 1893 and 1894 as *Ostrov Sakhalin* (*The Island of Sakhalin*), a work of social science, not literature. Chekhov found literary expression for the "Hell of Sakhalin" in his long short story "The Murder", the last section of which is set on Sakhalin, where the murderer Yakov loads coal in the night while longing for home. Chekhov's writing on Sakhalin, especially the traditions and habits of the Gilyak people, is the subject of a sustained meditation and analysis in Haruki Murakami's novel *1Q84*. It is also the subject of a poem by the Nobel Prize winner Seamus Heaney, "Chekhov on Sakhalin" (collected in the volume *Station Island*). Rebecca Gould has compared Chekhov's book on Sakhalin to Katherine Mansfield's *Urewera Notebook* (1907). In 2013, the Wellcome Trust-funded play 'A Russian Doctor', performed by Andrew Dawson and researched by Professor Jonathan Cole, explored Chekhov's experiences on Sakhalin Island.

### Melikhovo

Melikhovo, now a museum

Mikhail Chekhov, a member of the household at Melikhovo, described the extent of his brother's medical commitments:

> From the first day that Chekhov moved to Melikhovo, the sick began flocking to him from twenty miles around. They came on foot or were brought in carts, and often he was fetched to patients at a distance. Sometimes from early in the morning peasant women and children were standing before his door waiting.

Chekhov's expenditure on drugs was considerable, but the greatest cost was making journeys of several hours to visit the sick, which reduced his time for writing. However, Chekhov's work as a doctor enriched his writing by bringing him into intimate contact with all sections of Russian society: for example, he witnessed at first hand the peasants' unhealthy and cramped living conditions, which he recalled in his short story "Peasants". Chekhov visited the upper classes as well, recording in his notebook: "Aristocrats? The same ugly bodies and physical uncleanliness, the same toothless old age and disgusting death, as with market-women." In 1893/1894 he worked as a Zemstvo doctor in Zvenigorod, which has numerous sanatoriums and rest homes. A local hospital is named after him.

In 1894, Chekhov began writing his play *The Seagull* in a lodge he had built in the orchard at Melikhovo. In the two years since he had moved to the estate, he had refurbished the house, taken up agriculture and horticulture, tended the orchard and the pond, and planted many trees, which, according to Mikhail, he "looked after ... as though they were his children. Like Colonel Vershinin in his *Three Sisters*, as he looked at them he dreamed of what they would be like in three or four hundred years."

The first night of *The Seagull*, at the Alexandrinsky Theatre in St. Petersburg on 17 October 1896, was a fiasco, as the play was booed by the audience, stinging Chekhov into renouncing the theatre. But the play so impressed the theatre director Vladimir Nemirovich-Danchenko that he convinced his colleague Konstantin Stanislavski to direct a new production for the innovative Moscow Art Theatre in 1898. Stanislavski's attention to psychological realism and ensemble playing coaxed the buried subtleties from the text, and restored Chekhov's interest in playwriting. The Art Theatre commissioned more plays from Chekhov and the following year staged *Uncle Vanya*, which Chekhov had completed in 1896. In the last decades of his life he became an atheist.

### Yalta

In March 1897, Chekhov suffered a major haemorrhage of the lungs while on a visit to Moscow. With great difficulty he was persuaded to enter a clinic, where doctors diagnosed tuberculosis on the upper part of his lungs and ordered a change in his manner of life.

Chekhov with Leo Tolstoy at Yalta, 1900

After his father's death in 1898, Chekhov bought a plot of land on the outskirts of Yalta and built a villa (The White Dacha), into which he moved with his mother and sister the following year. Though he planted trees and flowers, kept dogs and tame cranes, and received guests such as Leo Tolstoy and Maxim Gorky, Chekhov was always relieved to leave his "hot Siberia" for Moscow or travels abroad. He vowed to move to Taganrog as soon as a water supply was installed there. In Yalta he completed two more plays for the Art Theatre, composing with greater difficulty than in the days when he "wrote serenely, the way I eat pancakes now". He took a year each over *Three Sisters* and *The Cherry Orchard*.

On 25 May 1901, Chekhov married Olga Knipper quietly, owing to his horror of weddings. She was a former protégée and sometime lover of Vladimir Nemirovich-Danchenko whom he had first met at rehearsals for *The Seagull*. Up to that point, Chekhov, known as "Russia's most elusive literary bachelor", had preferred passing liaisons and visits to brothels over commitment. He had once written to Suvorin:

> By all means I will be married if you wish it. But on these conditions: everything must be as it has been hitherto—that is, she must live in Moscow while I live in the country, and I will come and see her.... I promise to be an excellent husband, but give me a wife who, like the moon, won't appear in my sky every day.

Chekhov and Olga, 1901, on their honeymoon

The letter proved prophetic of Chekhov's marital arrangements with Olga: he lived largely at Yalta, she in Moscow, pursuing her acting career. In 1902, Olga suffered a miscarriage; and Donald Rayfield has offered evidence, based on the couple's letters, that conception occurred when Chekhov and Olga were apart, although other Russian scholars have rejected that claim. The literary legacy of this long-distance marriage is a correspondence that preserves gems of theatre history, including shared complaints about Stanislavski's directing methods and Chekhov's advice to Olga about performing in his plays.

In Yalta, Chekhov wrote one of his most famous stories, "The Lady with the Dog" (also translated from the Russian as "Lady with Lapdog"), which depicts what at first seems a casual liaison between a cynical married man and an unhappy married woman who meet while holidaying in Yalta. Neither expects anything lasting from the encounter. Unexpectedly though, they gradually fall deeply in love and end up risking scandal and the security of their family lives. The story masterfully captures their feelings for each other, the inner transformation undergone by the disillusioned male protagonist as a result of falling deeply in love, and their inability to resolve the matter by either letting go of their families or of each other.

### Death

In May 1903, Chekhov visited Moscow; the prominent lawyer Vasily Maklakov visited him almost every day. Maklakov signed Chekhov's will. By May 1904, Chekhov was terminally ill with tuberculosis. Mikhail Chekhov recalled that "everyone who saw him secretly thought the end was not far off, but the nearer [he] was to the end, the less he seemed to realise it". On 3 June, he set off with Olga for the German spa town of Badenweiler in the Black Forest in Germany, from where he wrote outwardly jovial letters to his sister Masha, describing the food and surroundings, and assuring her and his mother that he was getting better. In his last letter, he complained about the way German women dressed. Chekhov died on 15 July 1904 at the age of 44 after a long fight with tuberculosis, the same disease that killed his brother.

Chekhov's death has become one of "the great set pieces of literary history"—retold, embroidered, and fictionalized many times since, notably in the 1987 short story "Errand" by Raymond Carver. In 1908, Olga wrote this account of her husband's last moments:

> Anton sat up unusually straight and said loudly and clearly (although he knew almost no German): *Ich sterbe* ('I'm dying'). The doctor calmed him, took a syringe, gave him an injection of camphor, and ordered champagne. Anton took a full glass, examined it, smiled at me and said: 'It's a long time since I drank champagne.' He drained it and lay quietly on his left side, and I just had time to run to him and lean across the bed and call to him, but he had stopped breathing and was sleeping peacefully as a child ...

Chekhov's body was transported to Moscow in a refrigerated railway-car meant for oysters, a detail that offended Gorky. Some of the thousands of mourners followed the funeral procession of a General Keller by mistake, to the accompaniment of a military band. Chekhov was buried next to his father at the Novodevichy Cemetery.

## Legacy

Anton Chekhov museum in Alexandrovsk-Sakhalinsky, Russia. It is the house where he stayed in Sakhalin during 1890.

A few months before he died, Chekhov told the writer Ivan Bunin that he thought people might go on reading his writings for seven years. "Why seven?", asked Bunin. "Well, seven and a half", Chekhov replied. "That's not bad. I've got six years to live." Chekhov's posthumous reputation greatly exceeded his expectations. The ovations for the play *The Cherry Orchard* in the year of his death served to demonstrate the Russian public's acclaim for the writer, which placed him second in literary celebrity only to Tolstoy, who outlived him by six years. Tolstoy was an early admirer of Chekhov's short stories and had a series that he deemed "first quality" and "second quality" bound into a book. In the first category were: *Children*, *The Chorus Girl*, *A Play*, *Home*, *Misery*, *The Runaway*, *In Court*, *Vanka*, *Ladies*, *A Malefactor*, *The Boys*, *Darkness*, *Sleepy*, *The Helpmate*, and *The Darling*; in the second: *A Transgression*, *Sorrow*, *The Witch*, *Verochka*, *In a Strange Land*, *The Cook's Wedding*, *A Tedious Business*, *An Upheaval*, *Oh! The Public!*, *The Mask*, *A Woman's Luck*, *Nerves*, *The Wedding*, *A Defenceless Creature*, and *Peasant Wives.*

Chekhov's work also found praise from several of Russia's most influential radical political thinkers. If anyone doubted the gloom and miserable poverty of Russia in the 1880s, the anarchist theorist Peter Kropotkin responded, "read only Chekhov's novels!" Raymond Tallis further recounts that Vladimir Lenin believed his reading of the short story Ward No. 6 "made him a revolutionary". Upon finishing the story, Lenin is said to have remarked: "I absolutely had the feeling that I was shut up in Ward 6 myself!"

In Chekhov's lifetime, British and Irish critics generally did not find his work pleasing; E. J. Dillon thought "the effect on the reader of Chekhov's tales was repulsion at the gallery of human waste represented by his fickle, spineless, drifting people" and R. E. C. Long said "Chekhov's characters were repugnant, and that Chekhov revelled in stripping the last rags of dignity from the human soul". After his death, Chekhov was reappraised. Constance Garnett's translations won him an English-language readership and the admiration of writers such as James Joyce, Virginia Woolf, and Katherine Mansfield, whose story "The Child Who Was Tired" is similar to Chekhov's "Sleepy". The Russian critic D. S. Mirsky, who lived in England, explained Chekhov's popularity in that country by his "unusually complete rejection of what we may call the heroic values". In Russia itself, Chekhov's drama fell out of fashion after the revolution, but it was later incorporated into the Soviet canon. The character of Lopakhin, for example, was reinvented as a hero of the new order, rising from a modest background so as eventually to possess the gentry's estates.

Osip Braz, *Anton Chekhov*, 1898, oil on canvas; Tretyakov Gallery, Moscow

Despite Chekhov's reputation as a playwright, William Boyd asserts that his short stories represent the greater achievement. Raymond Carver, who wrote the short story "Errand" about Chekhov's death, believed that Chekhov was the greatest of all short story writers:

> Chekhov's stories are as wonderful (and necessary) now as when they first appeared. It is not only the immense number of stories he wrote—for few, if any, writers have ever done more—it is the awesome frequency with which he produced masterpieces, stories that shrive us as well as delight and move us, that lay bare our emotions in ways only true art can accomplish.

According to literary critic Daniel S. Burt, Chekhov was one of the greatest and most influential writers of all time.

### Style

One of the first non-Russians to praise Chekhov's plays was George Bernard Shaw, who subtitled his *Heartbreak House* "A Fantasia in the Russian Manner on English Themes", and pointed out similarities between the predicament of the British landed class and that of their Russian counterparts as depicted by Chekhov: "the same nice people, the same utter futility".

Ernest Hemingway, another writer influenced by Chekhov, was more grudging: "Chekhov wrote about six good stories. But he was an amateur writer." Comparing Chekhov to Tolstoy, Vladimir Nabokov wrote, "I do love Chekhov dearly. I fail, however, to rationalize my feeling for him: I can easily do so in regard to the greater artist, Tolstoy, with the flash of this or that unforgettable passage […], but when I imagine Chekhov with the same detachment all I can make out is a medley of dreadful prosaisms, ready-made epithets, repetitions, doctors, unconvincing vamps, and so forth; yet it is *his* works which I would take on a trip to another planet." Nabokov called "The Lady with the Dog" "one of the greatest stories ever written" in its depiction of a problematic relationship, and described Chekhov as writing "the way one person relates to another the most important things in his life, slowly and yet without a break, in a slightly subdued voice".

For the writer William Boyd, Chekhov's historical accomplishment was to abandon what William Gerhardie called the "event plot" for something more "blurred, interrupted, mauled or otherwise tampered with by life".

Virginia Woolf mused on the unique quality of a Chekhov story in *The Common Reader* (1925):

> But is it the end, we ask? We have rather the feeling that we have overrun our signals; or it is as if a tune had stopped short without the expected chords to close it. These stories are inconclusive, we say, and proceed to frame a criticism based upon the assumption that stories ought to conclude in a way that we recognise. In so doing we raise the question of our own fitness as readers. Where the tune is familiar and the end emphatic—lovers united, villains discomfited, intrigues exposed—as it is in most Victorian fiction, we can scarcely go wrong, but where the tune is unfamiliar and the end a note of interrogation or merely the information that they went on talking, as it is in Tchekov, we need a very daring and alert sense of literature to make us hear the tune, and in particular those last notes which complete the harmony.

Michael Goldman has said of the elusive quality of Chekhov's comedies: "Having learned that Chekhov is comic ... Chekhov is comic in a very special, paradoxical way. His plays depend, as comedy does, on the vitality of the actors to make pleasurable what would otherwise be painfully awkward—inappropriate speeches, missed connections, *faux pas*, stumbles, childishness—but as part of a deeper pathos; the stumbles are not pratfalls but an energized, graceful dissolution of purpose."

### Influence on dramatic arts

In the United States, Chekhov's reputation began its rise slightly later, partly through the influence of Stanislavski's system of acting, with its notion of subtext: "Chekhov often expressed his thought not in speeches", wrote Stanislavski, "but in pauses or between the lines or in replies consisting of a single word ... the characters often feel and think things not expressed in the lines they speak." The Group Theatre, in particular, developed the subtextual approach to drama, influencing generations of American playwrights, screenwriters, and actors, including Clifford Odets, Elia Kazan and, in particular, Lee Strasberg. In turn, Strasberg's Actors Studio and the "Method" acting approach influenced many actors, including Marlon Brando and Robert De Niro, though by then the Chekhov tradition may have been distorted by a preoccupation with realism. In 1981, the playwright Tennessee Williams adapted *The Seagull* as *The Notebook of Trigorin*. One of Anton's nephews, Michael Chekhov, would also contribute heavily to modern theatre, particularly through his unique acting methods which developed Stanislavski's ideas further.

Alan Twigg, the chief editor and publisher of the Canadian book review magazine *B.C. BookWorld* wrote:

> One can argue Anton Chekhov is the second-most popular writer on the planet. Only Shakespeare outranks Chekhov in terms of movie adaptations of their work, according to the movie database IMDb. ... We generally know less about Chekhov than we know about mysterious Shakespeare.

Chekhov has also influenced the work of Japanese playwrights, including Shimizu Kunio, Yōji Sakate, and Ai Nagai. Critics have noted the similarities in how Chekhov and Shimizu use a mixture of light humour with intense depictions of longing. Sakate adapted several of Chekhov's plays and transformed them in the general style of *nō*. Nagai also adapted Chekhov's plays, including *Three Sisters*, and transformed his dramatic style into Nagai's style of satirical realism while emphasising the social issues depicted in the play.

Chekhov's works have been adapted for the screen, including Sidney Lumet's *Sea Gull*, Louis Malle's *Vanya on 42nd Street*, and Nikita Mikhalkov's An Unfinished Piece for Mechanical Piano. Laurence Olivier's final effort as a film director was a 1970 adaptation of *Three Sisters* in which he also played a supporting role. Chekhov's work has also served as inspiration or been referenced in numerous films. In Andrei Tarkovsky's 1975 film *The Mirror*, characters discuss his short story "Ward No. 6". Woody Allen has been influenced by Chekhov and references to his works are present in many of his films including *Love and Death* (1975), *Interiors* (1978) and *Hannah and Her Sisters* (1986). Plays by Chekhov are also referenced in François Truffaut's 1980 drama film *The Last Metro*, which is set in a theatre. *The Cherry Orchard* has a role in the comedy film *Henry's Crime* (2011). A portion of a stage production of *Three Sisters* appears in the 2014 drama film *Still Alice*. The 2022 Foreign Language Oscar winner, *Drive My Car*, is centered on a production of *Uncle Vanya*.

Several of Chekhov's short stories were adapted as episodes of the 1986 Indian anthology television series *Katha Sagar*. Another Indian television series titled *Chekhov Ki Duniya* aired on DD National in the 1990s, adapting different works of Chekhov.

Nuri Bilge Ceylan's Palme d'Or winner *Winter Sleep* was adapted from the short story "The Wife" by Anton Chekhov.

## Publications
