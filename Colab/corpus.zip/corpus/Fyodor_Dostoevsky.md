---
title: "Fyodor Dostoevsky"
source: "https://en.wikipedia.org/wiki/Fyodor_Dostoevsky"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Fyodor Dostoevsky

Russian novelist (1821–1881)

**Fyodor Mikhailovich Dostoevsky** (11 November [O.S. 30 October] 1821 – 9 February [O.S. 28 January] 1881) was a Russian philosopher, novelist, short story writer, essayist and journalist. He is regarded as one of the greatest novelists in both Russian and world literature, and many of his works are considered highly influential masterpieces. Dostoevsky's literary works explore the human condition in the troubled political, social and spiritual atmospheres of 19th century Russia, and engage with a variety of philosophical and religious themes. His most acclaimed novels include *Crime and Punishment* (1866), *The Idiot* (1869), *Demons* (1872), *The Adolescent* (1875) and *The Brothers Karamazov* (1880). His *Notes from Underground*, a novella published in 1864, is considered one of the first works of existentialist literature.

Born in Moscow in 1821, Dostoevsky was introduced to literature at an early age through fairy tales and legends and through books by Russian and foreign authors. His mother died in 1837, and around the same time, he left school to enter the Nikolayev Military Engineering Institute (later renamed the Military Engineering-Technical University). After graduating, he worked as an engineer and briefly enjoyed a lavish lifestyle, translating books to earn extra money. In the mid-1840s, he wrote his first novel, *Poor Folk*, which gained him entry into Saint Petersburg's literary circles. However, he was arrested in 1849 for belonging to a literary group, the Petrashevsky Circle, that discussed banned books critical of Tsarist Russia. Dostoevsky was sentenced to death, but the sentence was commuted at the last moment. He spent four years in a Siberian hard labour camp, which inspired him to write *The House of the Dead* (1860–1862). Aside from the labour camp, they also followed six years of compulsory military service in exile. In the following years, Dostoevsky worked as a journalist, publishing and editing several magazines of his own and later *A Writer's Diary*, a collection of his writings. He began to travel around Western Europe and developed a gambling addiction, which led to financial hardship. For a time, he had to beg for money, but he eventually became one of the most widely read and highly regarded Russian writers.

Dostoevsky's body of work consists of thirteen novels, three novellas, seventeen short stories, and numerous other works. His writings were widely read both within and beyond his native Russia, influencing an equally great number of later writers, including Russians such as Aleksandr Solzhenitsyn and Anton Chekhov, the philosophers Albert Camus and Jean-Paul Sartre, and the emergence of Existentialism and Freudianism. Friedrich Nietzsche called him "the only psychologist from whom I had something to learn" in *Twilight of the Idols*, one of his final works before suffering a mental collapse. His books have been translated into over 170 languages and served as the inspiration for the cinema world.

## Ancestry

Parents

Maria Fyodorovna Dostoevskaya

Mikhail Andreyevich Dostoevsky

Dostoevsky's paternal ancestors were part of a Russian noble family of Russian Orthodox Christians. The family traced its roots back to Aslan Chelebi-Мurza, a Tatar warlord who defected from the Golden Horde and joined the Russian side in 1389, eventually converting to Christianity from Islam. A few centuries later, another ancestor of Dostoyevsky, Danilo Irtishch, was granted lands in the Pinsk region (for centuries part of the Polish–Lithuanian Commonwealth, now in Belarus) in 1509 for his services under a local prince, his progeny then taking the name "Dostoevsky" based on a village there called Dostojewo [pl] (derived from Old Polish *dostojnik* – dignitary).

Dostoevsky's immediate ancestors on his mother's side were merchants; the male line on his father's side were priests.

In 1809, the 20-year-old Mikhail Dostoevsky enrolled in Moscow's Imperial Medical-Surgical Academy. From there, he was assigned to a Moscow hospital, where he served as a military doctor, and in 1818, he was appointed a senior physician. In 1819, he married Maria Nechayeva. The following year, he took up a post at the Mariinsky Hospital for the poor. In 1828, when his two sons, Mikhail and Fyodor, were eight and seven, respectively, he was promoted to collegiate assessor, a position which raised his legal status to that of the nobility and enabled him to acquire a small estate in Darovoye, a town about 150 km from Moscow, where the family usually spent the summers. Dostoevsky's parents subsequently had seven more children: Varvara (1822–1893) – married a civil servant and lived a quiet life, Andrei (1825–1897) – memoirist and wrote about family history, Lyubov (born and died 1829), Vera (1829–1896) – married a doctor and maintained family ties, Nikolai (1831–1883) – struggled with alcoholism and had a troubled life, Aleksandra (1835–1889) – married a military officer and lived privately and Yelizaveta (born and died 1837).

## Childhood (1821–1836)

Fyodor Dostoevsky, born on 11 November [O.S. 30 October] 1821 in Moscow, was the second child of Dr Mikhail Dostoevsky and Maria Dostoevskaya (née Nechayeva). He was raised in the family home in the grounds of the Mariinsky Hospital for the Poor, which was in a lower class district on the edges of Moscow. Dostoevsky encountered the patients, who were at the lower end of the Russian social scale, when playing in the hospital gardens.

Dostoevsky was introduced to literature at an early age. From the age of three, he was read heroic sagas, fairy tales and legends by his nanny, Alena Frolovna, an especially influential figure in his upbringing and his love for fictional stories. When he was four, his mother used the Bible to teach him to read and write. His parents introduced him to a wide range of literature, including the Russian writers Nikolai Karamzin, Alexander Pushkin and Gavrila Derzhavin; Gothic fiction such as the works from the English novelist Ann Radcliffe; romantic works by Friedrich Schiller and Johann Wolfgang von Goethe; heroic tales by Miguel de Cervantes and Walter Scott; and Homer's epics, the *Iliad* and the *Odyssey*. Dostoevsky was greatly influenced by the work of Nikolai Gogol. Although his father's approach to education has been described as strict and harsh, Dostoevsky himself reported that his imagination was brought alive by nightly readings by his parents.

Some of his childhood experiences found their way into his writings. When a nine-year-old girl had been raped by a drunk, he was asked to fetch his father to attend to her. The incident haunted him, and the theme of the desire of a mature man for a young girl appears in *The Devils*, *The Brothers Karamazov*, *Crime and Punishment*, and other writings. An incident involving a family servant, or serf, in the estate in Darovoye, is described in "The Peasant Marey": when the young Dostoevsky imagines hearing a wolf in the forest, Marey, who is working nearby, comforts him.

Another memory that Dostoyevsky referred to in his prose was summer trips to his father's estate in the Kashirsky District of the Tula Governorate, which was purchased between 1831 and 1833.

Although Dostoevsky had a delicate physical constitution, his parents described him as hot-headed, stubborn, and cheeky. In 1833, Dostoevsky's father, who was profoundly religious, sent him to a French boarding school and then to the Chermak boarding school. He was described as a pale, introverted dreamer and an over-excitable romantic. To pay the school fees, his father borrowed money and extended his private medical practice. Dostoevsky felt out of place among his aristocratic classmates at the Moscow school, and the experience was later reflected in some of his works, notably *The Adolescent*.

## Youth (1836–1843)

On 27 February 1837, Dostoevsky's mother died of tuberculosis. The previous May, Dostoevsky's parents sent him and his elder brother Mikhail (the two eldest Dostoevsky children) to Saint Petersburg to attend the Nikolayev Military Engineering Institute (later renamed the Military Engineering-Technical University), forcing the brothers to abandon their academic studies for military careers. Dostoevsky entered the academy in January 1838, but only with the help of family members. Mikhail was refused admission on health grounds and was sent to an academy in Reval (now Tallinn, Estonia).

Dostoevsky disliked the academy, primarily because of his lack of interest in science, mathematics, and military engineering and his preference for drawing and architecture. As his friend Konstantin Trutovsky once said, "There was no student in the entire institution with less of a military bearing than F.M. Dostoevsky. He moved clumsily and jerkily; his uniform hung awkwardly on him; and his knapsack, shako and rifle all looked like some sort of fetter he had been forced to wear for a time and which lay heavily on him." Dostoevsky's character and interests made him an outsider among his 120 classmates: he showed bravery and a strong sense of justice, protected newcomers, aligned himself with teachers, criticised corruption among officers, and helped poor farmers. Although he was solitary and inhabited his own literary world, he was respected by his classmates. His reclusiveness and interest in religion earned him the nickname "Monk Photius".

Signs of Dostoevsky's epilepsy may have first appeared at 17 years old on learning of the death of his father on 16 June 1839, although the reports of a seizure originated from accounts written by his daughter (later expanded by Sigmund Freud) which are now considered to be unreliable. His father's official cause of death was an apoplectic stroke, but a neighbour, Pavel Khotiaintsev, accused the father's serfs of murder. Had the serfs been found guilty and sent to Siberia, Khotiaintsev would have been in a position to buy the vacated land. The serfs were acquitted in a trial in Tula, but Dostoevsky's brother Mikhail perpetuated the story. After his father's death, Dostoevsky continued his studies, passed his exams and obtained the rank of engineer cadet, entitling him to live away from the academy. He visited Mikhail in Reval (Tallinn) and frequently attended concerts, operas, plays and ballets. During this time, two of his friends introduced him to gambling.

On 12 August 1843, Dostoevsky took a job as a lieutenant engineer and lived with Adolph Totleben in an apartment owned by Dr Rizenkampf, a friend of Mikhail. Rizenkampf characterised him as "no less good-natured and no less courteous than his brother, but when not in a good mood he often looked at everything through dark glasses, became vexed, forgot good manners, and sometimes was carried away to the point of abusiveness and loss of self-awareness". Dostoevsky's first completed literary work, a translation of Honoré de Balzac's novel *Eugénie Grandet*, was published in June and July 1843 in the 6th and 7th volumes of the journal *Repertoire and Pantheon*, followed by several other translations. None were successful and his financial difficulties led him to write a novel.

## Career

### Early career (1844–1849)

Dostoevsky, 1847

Dostoevsky completed his first novel, *Poor Folk*, in May 1845. His friend Dmitry Grigorovich, with whom he was sharing an apartment at the time, took the manuscript to the poet Nikolay Nekrasov, who in turn showed it to the influential literary critic Vissarion Belinsky. Belinsky described it as Russia's first "social novel". *Poor Folk* was released on 15 January 1846 in the *St Petersburg Collection* almanac and became a commercial success.

Dostoevsky felt that his military career would endanger his now flourishing literary career, so he wrote a letter asking to resign his post. Shortly thereafter, he wrote his second novel, *The Double*, which appeared in the journal *Notes of the Fatherland* on 30 January 1846, before being published in February. Around the same time, Dostoevsky discovered socialism through the writings of the French thinkers Charles Fourier, Étienne Cabet, Pierre-Joseph Proudhon and Henri de Saint-Simon. Through his relationship with Belinsky, he expanded his knowledge of the philosophy of socialism. However, his Russian Orthodox faith and religious sensibilities could not accord with Belinsky's admixture of atheism, utilitarianism and scientific materialism, leading to increasing friction between them. Dostoevsky eventually parted with him and his associates.

After *The Double* received negative reviews (including a particularly scathing one from Belinsky), Dostoevsky's health declined and his seizures became more frequent, but he continued writing. From 1846 to 1848, he published several short stories in the magazine *Notes of the Fatherland*, including "Mr. Prokharchin", "The Landlady", "A Weak Heart", and "White Nights". The negative reception of these stories, combined with his health problems and Belinsky's attacks, caused him distress and financial difficulty, but these were greatly alleviated when he joined the utopian socialist Beketov circle, a tightly knit community that helped him to survive. When the circle dissolved, Dostoevsky befriended Apollon Maykov and his brother Valerian. In 1846, on the recommendation of the poet Aleksey Pleshcheyev, he joined the Petrashevsky Circle, founded by Mikhail Petrashevsky, who had proposed social reforms in Russia. Mikhail Bakunin once wrote to Alexander Herzen that the group was "the most innocent and harmless company" and its members were "systematic opponents of all revolutionary goals and means". Dostoevsky used the circle's library on Saturdays and Sundays and occasionally participated in their discussions on freedom from censorship and the abolition of serfdom. Bakunin's description, however, was not true of the aristocrat Nikolay Speshnev, who joined the circle in 1848 and set about creating a secret revolutionary society from among its members. Dostoevsky himself became a member of this society, was aware of its aims, and actively participated, although he harboured significant doubts about their actions and intentions.

In 1849, the first parts of *Netochka Nezvanova*, a novel Dostoevsky had been planning since 1846, were published in *Notes of the Fatherland*, but his banishment ended the project, leaving only what was supposed to be the prologue of the novel. Dostoevsky never attempted to complete it, leaving only a sketch of the novel behind.

### Siberian exile (1849–1854)

A sketch of the Petrashevsky Circle mock execution

The members of the Petrashevsky Circle were denounced to an official at the Ministry of Internal Affairs, Ivan Liprandi. Dostoevsky was accused of reading works by Belinsky, including the banned *Letter to Gogol*, and of circulating copies of these and other works. Antonelli, the government agent who had reported the group, wrote in his statement that at least one of the papers criticised Russian politics and religion. Dostoevsky responded to these charges by declaring that he had read the essays only "as a literary monument, neither more nor less"; he spoke of "personality and human egoism" rather than of politics. Even so, he and his fellow "conspirators" were arrested on 23 April 1849 at the request of Count Alexey Fyodorovich Orlov and Tsar Nicholas I, who feared a revolution like the Decembrist revolt of 1825 in Russia and the Revolutions of 1848 in Europe. The members were held in the well-defended Peter and Paul Fortress, which housed the most dangerous convicts.

The case was discussed for four months by an investigative commission headed by the Tsar, with Adjutant General Ivan Nabokov, senator Prince Pavel Gagarin, Prince Vasili Dolgorukov, General Yakov Rostovtsev and General Leonty Dubelt, head of the secret police. They sentenced the members of the circle to death by firing squad, and the prisoners were taken to Semyonov Place in Saint Petersburg on 23 December 1849. They were split into three-man groups and the first group was taken in front of the firing squad. Dostoevsky was the third in the second row; next to him stood Pleshcheyev and Durov. The execution was stayed when a cart delivered a letter from the tsar commuting the sentence. Dostoevsky later described the experience of what he believed to be the last moments of his life in his novel *The Idiot*; the main character, Prince Myshkin, tells the story of a young man sentenced to death by firing squad but reprieved at the last moment. Prince Myshkin describes the experience from the point of view of the victim and considers the philosophical and spiritual implications.

Dostoevsky served four years of exile with hard labour at a katorga prison camp in Omsk, Siberia, followed by a term of compulsory military service. After a fourteen-day sleigh ride, the prisoners reached Tobolsk, a prisoner way station. Despite the circumstances, Dostoevsky consoled the other prisoners, such as the Petrashevist Ivan Yastrzhembsky, who was surprised by Dostoevsky's kindness and eventually abandoned his decision to kill himself. In Tobolsk, they received food and clothes from the Decembrist women, as well as several copies of the New Testament with a ten-rouble banknote inside each copy. Eleven days later, Dostoevsky reached Omsk together with just one other member of the Petrashevsky Circle, the writer Sergei Durov. Dostoevsky described his barracks:

> In summer, intolerable closeness; in winter, unendurable cold. All the floors were rotten. Filth on the floors an inch thick; one could slip and fall [...] We were packed like herrings in a barrel [...] There was no room to turn around. From dusk to dawn, it was impossible not to behave like pigs [...] Fleas, lice, and black beetles by the bushel [...]

Classified as "one of the most dangerous convicts", Dostoevsky had his hands and feet shackled until his release. He was only permitted to read his copy of the New Testament. In addition to his seizures, he had hemorrhoids, lost weight and was "burned by some fever, trembling and feeling too hot or too cold every night". The smell of the privy pervaded the entire building, and the small bathroom had to suffice for more than 200 people. Dostoevsky was occasionally sent to the military hospital, where he read newspapers and Charles Dickens novels. He was respected by most of the other prisoners, but despised by some Polish political prisoners because of his Russian nationalism and anti-Polish sentiments.

### Release from prison and first marriage (1854–1866)

Dostoevsky as a military engineer in 1858 or 1859, portrait by Solomon Leibin (Соломон Лейбин)

Dostoevsky in Paris, 1863

After his release on 14 February 1854, Dostoevsky asked Mikhail to help him financially and to send him books by Giambattista Vico, François Guizot, Leopold von Ranke, Georg Wilhelm Friedrich Hegel and Immanuel Kant. *The House of the Dead*, based on his experience in prison, was published in 1861 in the journal *Vremya* ("Time") – it was the first published novel about Russian prisons. Before moving in mid-March to Semipalatinsk, where he was forced to serve in the Siberian Army Corps of the Seventh Line Battalion, Dostoevsky met the geographer Pyotr Semyonov and the ethnographer Shoqan Walikhanov. Around November 1854, he met Baron Alexander Egorovich Wrangel, an admirer of his books, who had attended the aborted execution. They both rented houses in the Cossack Garden outside Semipalatinsk. Wrangel remarked that Dostoevsky "looked morose. His sickly, pale face was covered with freckles, and his blond hair was cut short. He was a little over average height and looked at me intensely with his sharp, grey-blue eyes. It was as if he were trying to look into my soul and discover what kind of man I was."

In Semipalatinsk, Dostoevsky tutored several schoolchildren and came into contact with upper-class families, including that of Lieutenant-Colonel Belikhov, who used to invite him to read passages from newspapers and magazines. During a visit to Belikhov, Dostoevsky met Maria Dmitrievna Isaeva and fell in love with her; Isaeva and her son later moved with Dostoevsky to Barnaul. In 1856, Dostoevsky sent a letter through Wrangel to General Eduard Totleben, apologising for his activity in several utopian circles. As a result, he obtained the right to publish books and to marry, although he remained under police surveillance for the rest of his life. Isaeva and Dostoevsky married in Kuznetsk on 7 February 1857, even though she had initially refused his marriage proposal, stating that they were not meant for each other and that his poor financial situation precluded marriage. Their family life was unhappy and she found it difficult to cope with his seizures. Describing their relationship, he wrote: "Because of her strange, suspicious and fantastic character, we were definitely not happy together, but we could not stop loving each other; and the more unhappy we were, the more attached to each other we became". They mostly lived apart. In 1859 he was released from military service because of deteriorating health and was granted permission to return to European Russia, first to Tver, where he met his brother for the first time in ten years, and then to Saint Petersburg.

The short story "A Little Hero" (Dostoevsky's only work completed in prison) appeared in a journal, but "Uncle's Dream" and "The Village of Stepanchikovo" were not published until 1860. *Notes from the House of the Dead* was released in *Russky Mir* (Russian World) in September 1860. *Humiliated and Insulted* was published in the new *Vremya* magazine, which had been created with the help of funds from his brother's cigarette factory.

Dostoevsky travelled to Western Europe for the first time on 7 June 1862, visiting Cologne, Berlin, Dresden, Wiesbaden, Belgium and Paris. In London, he met Alexander Herzen and visited the Crystal Palace. He travelled with Nikolay Strakhov through Switzerland and several North Italian cities, including Turin, Livorno, and the central Italian city of Florence. He recorded his impressions of those trips in the essay "Winter Notes on Summer Impressions", in which he also criticised capitalism, social modernisation, materialism, Catholicism and Protestantism. Dostoevsky viewed the Crystal Palace as a monument to soulless modern society, the myth of progress, and the worship of empty materialism.

From August to October 1863, Dostoevsky made another trip to Western Europe. He met his second love, Polina Suslova, in Paris and lost nearly all his money gambling in Wiesbaden and Baden-Baden. In 1864, his wife Maria and his brother Mikhail died; Dostoevsky then became the lone parent of his stepson Pasha and the sole supporter of his brother's family. The failure of *Epoch*, the magazine he had founded with Mikhail after the suppression of *Vremya*, worsened his financial situation, although the continued help of his relatives and friends averted bankruptcy.

### Second marriage and honeymoon (1866–1871)

Memorial plaque to Dostoevsky in Baden-Baden

Plaque for baby Sofya

The first two parts of *Crime and Punishment* were published in January and February 1866 in the periodical *The Russian Messenger*, attracting at least 500 new subscribers to the magazine.

Dostoevsky returned to Saint Petersburg in mid-September and promised his editor, Fyodor Stellovsky, that he would complete a novel titled *The Gambler* by November, although he had not yet begun writing it. One of Dostoevsky's friends, Aleksandr Milyukov, advised him to hire a secretary. Dostoevsky contacted stenographer Pavel Olkhin from Saint Petersburg, who recommended his pupil, the twenty-year-old Anna Grigoryevna Snitkina. Her shorthand helped Dostoevsky to complete *The Gambler* on 30 October, after 26 days' work. She remarked that Dostoevsky was of average height but always tried to carry himself erect. "He had light brown, slightly reddish hair; he used some hair conditioner, and he combed his hair in a diligent way [...] his eyes, they were different: one was dark brown; in the other, the pupil was so big that you could not see its colour, [this was caused by an injury]. The strangeness of his eyes gave Dostoyevsky a mysterious appearance. His face was pale, and it looked unhealthy."

On 15 February 1867, Dostoevsky and Snitkina married in Trinity Cathedral, Saint Petersburg. On 14 April 1867, they began a delayed honeymoon in Germany; the 7,000 rubles he had earned from *Crime and Punishment* did not cover their debts, forcing Anna to sell her valuables to finance their trip. They stayed in Berlin, visited the Gemäldegalerie Alte Meister in Dresden, where he sought inspiration for his writing, and also stopped in Frankfurt, Darmstadt, Heidelberg and Karlsruhe. They spent five weeks in Baden-Baden, where Dostoevsky had a quarrel with Ivan Turgenev and again lost much money at the roulette table. At one point, his wife was reportedly forced to pawn her underwear.

In September 1867, Dostoevsky began work on *The Idiot*, and after a prolonged planning process that bore little resemblance to the published novel, he eventually managed to write the first 100 pages in only 23 days; the serialisation began in *The Russian Messenger* in January 1868.

By 1868, the couple had moved on to Geneva. Their first child, Sofya, had been conceived in Baden-Baden and was born in Geneva on 5 March 1868. The baby died of pneumonia three months later, and Anna recalled how Dostoevsky "wept and sobbed like a woman in despair". Sofya was buried at the Cimetière des Rois in Geneva; her grave was later dissolved, but in 1986 the International Dostoevsky Society donated a commemorative plaque in her honour.

After Sofya's death, the couple continued their travels through Europe. They first went to Vevey and then Milan before continuing to Florence, where Dostoevsky completed *The Idiot* in January 1869; its final part appeared in *The Russian Messenger* in the following month. Later that year, in Dresden, Anna gave birth to their second daughter, Lyubov, on 26 September. After hearing news that the socialist revolutionary group "People's Vengeance" had murdered one of its own members, Ivan Ivanov, on 21 November 1869, Dostoevsky began writing *Demons*.

In April 1871, Dostoevsky made a final visit to a gambling hall in Wiesbaden. Anna claimed that he stopped gambling after the birth of their second daughter, but this is a subject of debate. During a train trip to Berlin, he burnt several manuscripts, including those of *The Idiot*, because he was concerned about potential problems with customs. The Dostoevsky family finally arrived back in Saint Petersburg on 8 July, marking the end of a honeymoon (originally planned for three months) that had lasted over four years.

### Back in Russia (1871–1875)

Dostoevsky (left) in the Haymarket, 21/22 March 1874

Back in Russia in July 1871, the family was again in financial trouble and had to sell their remaining possessions. Their son Fyodor was born on 16 July, and they moved to an apartment near the Institute of Technology soon after. They hoped to cancel their large debts by selling their rental house in Peski, but difficulties with the tenant resulted in a relatively low selling price, and disputes with their creditors continued. Anna proposed that they raise money on her husband's copyrights and negotiate with the creditors to pay off their debts in instalments.

Dostoevsky revived his friendships with Maykov and Strakhov and made new acquaintances, including church politician Terty Filipov and the brothers Vsevolod and Vladimir Solovyov. Konstantin Pobedonostsev, future Imperial High Commissioner of the Most Holy Synod, influenced Dostoevsky's political progression to conservatism.

Around early 1872, the family spent several months in Staraya Russa, a town known for its mineral spa. Dostoevsky's work was delayed when Anna's sister Maria Svatkovskaya died on 1 May 1872, from either typhus or malaria, and Anna developed an abscess on her throat.

The family returned to Saint Petersburg in September. *Demons* was finished on 26 November 1872 and released in the following January by the "Dostoevsky Publishing Company", which the Dostoevskys had just established. Anna managed the company's finances, sold the book out of their apartment and only accepted cash payments; but *Demons* was a success, selling around 3,000 copies. Dostoevsky proposed that they establish a new periodical called *A Writer's Diary*, to include a collection of essays, but funds were lacking. The *Diary* was instead published in Vladimir Meshchersky's magazine *The Citizen*, beginning on 1 January 1873, in return for a salary of 3,000 rubles per year. That summer, Anna returned to Staraya Russa with the children, while Dostoevsky stayed in Saint Petersburg to continue with his *Diary*.

In March 1874, Dostoevsky left *The Citizen* because of the stressful work and interference from the Russian bureaucracy. In his fifteen months with *The Citizen*, he had been taken to court twice: on 11 June 1873 for citing the words of Prince Meshchersky without permission, and again on 23 March 1874. Dostoevsky offered to sell a new novel he had not yet begun to write to *The Russian Messenger*, but the magazine refused. Nikolay Nekrasov then suggested that he publish in another periodical, *Notes of the Fatherland*, which offered Dostoevsky 250 rubles for each printer's sheet – 100 more than he would have earned with *The Russian Messenger*. Dostoevsky accepted.

That year, his health began to decline. Dostoevsky consulted several doctors in Saint Petersburg and was advised to take a cure outside Russia. In July, he travelled to Bad Ems, where a physician diagnosed him with acute catarrh. During his stay there, he began writing *The Adolescent*, and he returned to Saint Petersburg in late July. Anna proposed that they spend the winter in Staraya Russa to allow Dostoevsky to rest, although doctors had suggested a second visit to Ems because his health had previously improved there.

On 10 August 1875, his son Alexey was born in Staraya Russa, and in mid-September the family returned to Saint Petersburg. Dostoevsky finished *The Adolescent* at the end of 1875, although passages of it had been serialised in *Notes of the Fatherland* since January. *The Adolescent* chronicles the life of Arkady Dolgoruky, the illegitimate child of the landowner Versilov and a peasant mother. It deals primarily with the relationship between father and son, which became a frequent theme in Dostoevsky's subsequent works.

### Last years (1876–1881)

Dostoevsky, 1879

Dostoevsky's funeral

In early 1876, Dostoevsky continued work on his *Diary*, compiling pieces from the periodical into a book. The book, titled A Writer's Diary, is a collection of numerous essays and a few short stories about society, religion, politics and ethics, and it sold more than twice as many copies as his previous books. Dostoevsky began to receive more letters from readers than ever before, and people of all ages and occupations visited him. With assistance from Anna's brother, the family bought a dacha in Staraya Russa. In the summer of 1876, Dostoevsky began experiencing shortness of breath again. He visited Ems for the third time and was told that he might live for another 15 years if he moved to a healthier climate. Upon returning to Russia, Tsar Alexander II ordered Dostoevsky to visit his palace to present the *Diary* to him, and he asked him to educate his sons, Sergey and Paul. This visit further increased Dostoevsky's circle of acquaintances. He was a frequent guest in several salons in Saint Petersburg and met many famous people, including Countess Sophia Tolstaya, Yakov Polonsky, Sergei Witte, Alexey Suvorin, Anton Rubinstein and Ilya Repin.

Dostoevsky's health declined further, and in March 1877, he had four epileptic seizures. Rather than returning to Ems, he visited Maly Prikol, a manor near Kursk. While returning to St Petersburg to finalise his *Diary*, he visited Darovoye, where he had spent much of his childhood. In December, he attended Nekrasov's funeral and gave a speech. He was appointed an honorary member of the Russian Academy of Sciences, from which he received an honorary certificate in February 1879. He declined an invitation to an international congress on copyright in Paris after his son Alyosha had a severe epileptic seizure and died on 16 May.

The family later moved to the apartment where Dostoevsky had written his first works. Around this time, he was elected to the board of directors of the Slavic Benevolent Society in Saint Petersburg, and that summer he was elected to the honorary committee of the Association Littéraire et Artistique Internationale, whose members included Victor Hugo, Ivan Turgenev, Paul Heyse, Alfred Tennyson, Anthony Trollope, Henry Longfellow, Ralph Waldo Emerson and Leo Tolstoy.

Dostoevsky made his fourth and final visit to Ems in early August 1879. He was diagnosed with early-stage pulmonary emphysema, which his doctor believed could be successfully managed, but not cured.

On 3 February 1880, Dostoevsky was elected vice-president of the Slavic Benevolent Society and was invited to speak at the unveiling of the Pushkin memorial in Moscow. On 8 June, he delivered his speech, giving an impressive performance that had a significant emotional impact on his audience. His speech was met with thunderous applause, and even his long-time rival Turgenev embraced him. Konstantin Staniukovich praised the speech in his essay "The Pushkin Anniversary and Dostoevsky's Speech" in *The Business*, writing that "the language of Dostoevsky's [Pushkin Speech] really looks like a sermon. He speaks with the tone of a prophet. He makes a sermon like a pastor; it is very deep, sincere, and we understand that he wants to impress the emotions of his listeners." The speech was criticised by liberal political scientist Aleksandr Gradovsky, who thought that Dostoevsky idolised "the people", and by the conservative thinker Konstantin Leontiev, who, in his essay "On Universal Love", compared the speech to French utopian socialism. The attacks led to a further deterioration in his health.

## Death

Dostoevsky on his bier, drawing by Ivan Kramskoi, 1881

Dostoevsky's grave in Saint Petersburg

On 6 February [O.S. 25 January] 1881, while searching for members of the terrorist organisation Narodnaya Volya ("The People's Will") who would soon assassinate Tsar Alexander II, the Tsar's secret police executed a search warrant in the apartment of Alexander Barannikov, one of Dostoevsky's neighbors. On the following day, Dostoevsky suffered a pulmonary hemorrhage. Anna denied that the search had caused it, saying that the hemorrhage had occurred after her husband had been looking for a dropped pen-holder. After he suffered another hemorrhage, Anna called the doctors, who gave a poor prognosis. A third hemorrhage followed shortly afterwards. While seeing his children before dying, Dostoevsky requested the parable of the Prodigal Son to be read to his children. The profound meaning of this request is pointed out by Joseph Frank:

> It was this parable of transgression, repentance, and forgiveness that he wished to leave as a last heritage to his children, and it may well be seen as his own ultimate understanding of the meaning of his life and the message of his work.

Among Dostoevsky's last words was his quotation of Matthew 3:14–15: "But John forbade him, saying, I have a need to be baptised of thee, and comest thou to me? And Jesus answering said unto him, Suffer it to be so now: for thus it becometh us to fulfil all righteousness", and he finished with "Hear now — permit it. Do not restrain me!" His last words to his wife Anna were: "Remember, Anya, I have always loved you passionately and have never been unfaithful to you ever, even in my thoughts!" When he died, his body was placed on a table, following Russian custom.

Dostoevsky was interred in the Tikhvin Cemetery at the Alexander Nevsky Convent, near his favourite poets, Nikolay Karamzin and Vasily Zhukovsky. It is unclear how many attended his funeral. According to one reporter, more than 100,000 mourners were present, while others describe attendance between 40,000 and 50,000. His tombstone is inscribed with lines from the New Testament:

> Verily, verily, I say unto you, Except a corn of wheat fall into the ground and die, it abideth alone: but if it dies, it bringeth forth much fruit.

— John 12:24

## Personal life

### Pre-marriage romantic relationships

Dostoevsky was romantically involved with several women before his marriage to Anna Snitkina in 1867. He had his first known affair with Avdotya Panaeva, whom he met in Ivan Panaev's circle in the early 1840s. He described her as educated, interested in literature, and a femme fatale. He admitted later that he was uncertain about their relationship. According to Anna Dostoevskaya's memoirs, Dostoevsky once asked his sister's sister-in-law, Yelena Ivanova, whether she would marry him, hoping to replace her mortally ill husband after he died, but she rejected his proposal.

Dostoevsky and Polina Suslova had a short but intimate affair, which peaked in the winter of 1862–1863. Suslova's dalliance with a Spaniard in late spring and Dostoevsky's gambling addiction and age ended their relationship. He later described her in a letter to Nadezhda Suslova as a "great egoist. Her egoism and her vanity are colossal. She demands *everything* of other people, all the perfections, and does not pardon the slightest imperfection in the light of other qualities that one may possess", and later stated, "I still love her, but I do not want to love her any more. She doesn't deserve this love [...]"

In 1858, Dostoevsky had a romance with comic actress Aleksandra Ivanovna Schubert. Although she divorced Dostoevsky's friend Stepan Yanovsky, she would not live with him. Dostoevsky did not love her either, but they were probably good friends. She wrote that he "became very attracted to me".

Through a worker in *Epoch*, Dostoevsky learned of the Russian-born Martha Brown (née Elizaveta Andreyevna Chlebnikova), who had had affairs with several Westerners. Her relationship with Dostoevsky is known only through letters written between November 1864 and January 1865.

In 1865, Dostoevsky met Anna Korvin-Krukovskaya. Their relationship is not verified; Anna Dostoevskaya spoke of a good affair, but Korvin-Krukovskaya's sister, the mathematician Sofia Kovalevskaya, thought that Korvin-Krukovskaya had rejected him.

### Political beliefs

In his youth, Dostoevsky enjoyed reading Nikolai Karamzin's *History of the Russian State* (published 1818–1829), which praised conservatism and Russian independence, ideas that Dostoevsky would embrace later in life. Before his arrest for participating in the Petrashevsky Circle in 1849, Dostoevsky remarked, "As far as I am concerned, nothing was ever more ridiculous than the idea of a republican government in Russia." In an 1881 edition of his *Diaries*, Dostoevsky stated that the Tsar and the people should form a unity: "For the people, the tsar is not an external power, not the power of some conqueror [...] but a power of all the people, an all-unifying power the people themselves desired."

While critical of serfdom, Dostoevsky was sceptical about the creation of a constitution, a concept he viewed as unrelated to Russia's history. He described it as a mere "gentleman's rule" and believed that "a constitution would simply enslave the people". He advocated social change instead, for example, the removal of the feudal system and a weakening of the divisions between the peasantry and the affluent classes. His ideal was a utopian, Christianised Russia where "if everyone were actively Christian, not a single social question would come up [...] If they were Christians, they would settle everything". He thought democracy and oligarchy were poor systems; of France he wrote, "the oligarchs are only concerned with the interest of the wealthy; the democrats, only with the interest of the poor; but the interests of society, the interest of all and the future of France as a whole — no one there bothers about these things." He maintained that political parties ultimately led to social discord. In the 1860s, he discovered *Pochvennichestvo*, a movement similar to Slavophilism in that it rejected Europe's culture and contemporary philosophical movements, such as nihilism and materialism. *Pochvennichestvo* differed from Slavophilism in aiming to establish, not an isolated Russia, but a more open state modelled on the Russia of Peter the Great.

In his incomplete article "Socialism and Christianity", Dostoevsky claimed that civilisation ("the second stage in human history") had become degraded, and that it was moving towards liberalism and losing its faith in God. He asserted that the traditional concept of Christianity should be recovered. He thought that contemporary Western Europe had "rejected the single formula for their salvation that came from God and was proclaimed through revelation, "Thou shalt love thy neighbor as thyself", and replaced it with practical conclusions such as, *Chacun pour soi et Dieu pour tous* [Every man for himself and God for all], or "scientific" slogans like the struggle for survival". He considered this crisis to be the consequence of the collision between communal and individual interests, brought about by a decline in religious and moral principles.

Dostoevsky distinguished three "enormous world ideas" prevalent in his time: Roman Catholicism, Protestantism and (Russian) Orthodoxy. He claimed that Catholicism had continued the tradition of Imperial Rome and had thus become anti-Christian and proto-socialist, inasmuch as the Church's interest in political and mundane affairs led it to abandon the idea of Christ. For Dostoevsky, socialism was "the latest incarnation of the Catholic idea" and its "natural ally". He found Protestantism self-contradictory and claimed that it would ultimately lose power and spirituality. He deemed (Russian) Orthodoxy to be the ideal form of Christianity.

For all that, to place Dostoevsky politically is not simple: as a Christian, he rejected atheistic socialism; as a traditionalist, he rejected the destruction of the institutions; and, as a pacifist, he rejected any violent method or upheaval led by either progressives or reactionaries. He supported private property and business rights and did not agree with many criticisms of the free market from the socialist utopians of his time.

During the Russo-Turkish War of 1877–1878, Dostoevsky asserted that war might be necessary if salvation were to be granted. He wanted the Muslim Ottoman Empire eliminated and the Christian Byzantine Empire restored, and he hoped for the liberation of Balkan Slavs and their unification with the Russian Empire. Under the ideology of *pochvennichestvo*, he advocated for a Slavic federation to be led by Russia; the federation, excluding Slavs, would also include Hungarians, Romanians and Greeks "whose historical destinies have attached them by indestructible bonds to the Slav world". This federation would include Constantinople and the Dardanelles Straits, which would be taken away from the Ottoman Empire.

Historian Richard Pipes placed Dostoevsky as being firmly in the tradition of Russian Conservatism, describing *Crime and Punishment*, *The Brothers Karamazov*, and *Demons* as political novels. Pipes was critical of Dostoevsky's politics, saying that in the ordinary sense, the author "knew little and understood less" and his political analysis went little beyond xenophobia and "crude" jingoism. Instead, it was in Dostoevsky's understanding of the "psychological implications of radicalism" that his greatness lay.

### Ethnic beliefs

Many characters in Dostoevsky's works, including Jews, have been described as displaying negative stereotypes. In an 1877 letter to Arkady Kovner, a Jew who had accused Dostoevsky of antisemitism, he replied with the following:

> "I am not an enemy of the Jews at all and never have been. But as you say, its 40 century existence proves that this tribe has exceptional vitality, which would not help, during the course of its history, taking the form of various Status in Statu [...] how can they fail to find themselves, even if only partially, at variance with the indigenous population – the Russian tribe?"

Dostoevsky held to a Pan-Slavic ideology that was conditioned by the Ottoman occupations of Eastern Europe. In 1876, the Slavic populations of modern-day South-Eastern Serbia outside of the Principality of Serbia (independent since 1868) and of the region of Bulgaria rose against their Ottoman overlords, but the rebellion was put down. In the process, an estimated 12,000 people were killed. In his diaries, he scorned Westerners and those who were against the Pan-Slavic movement. This ideology was motivated in part by the desire to promote a common Orthodox Christian heritage, which he saw as both unifying and a force for liberation.

### Religious beliefs

The New Testament that Dostoevsky took with him to prison in Siberia

Dostoevsky was an Orthodox Christian who was raised in a religious family and knew the Gospel from a very young age. He was influenced by the Russian translation of Johannes Hübner's *One Hundred and Four Sacred Stories from the Old and New Testaments Selected for Children* (partly a German bible for children and partly a catechism). He attended Sunday liturgies from an early age and took part in annual pilgrimages to the St. Sergius Trinity Monastery. A deacon at the hospital gave him religious instruction. Among his most cherished childhood memories were reciting prayers in front of guests and reading passages from the Book of Job that impressed him while "still almost a child."

According to an officer at the military academy, Dostoevsky was profoundly religious, followed Orthodox practice, and regularly read the Gospels and Heinrich Zschokke's *Die Stunden der Andacht* ("Hours of Devotion"), which "preached a sentimental version of Christianity entirely free from dogmatic content and with a strong emphasis on giving Christian love a social application". This book may have prompted his later interest in Christian socialism. Through the literature of E. T. A. Hoffmann, Honoré de Balzac, Eugène Sue, and Johann Wolfgang von Goethe, Dostoevsky created his own belief system, similar to Russian sectarianism and the Old Belief. After his arrest, aborted execution, and subsequent imprisonment, he focused intensely on the figure of Christ and on the New Testament, the only book allowed in prison. In a January 1854 letter to the woman who had sent him the New Testament, Dostoevsky wrote that he was a "child of unbelief and doubt up to this moment, and I am certain that I shall remain so to the grave". He also wrote that "even if someone were to prove to me that the truth lay outside Christ, I should choose to remain with Christ rather than with the truth".

In Semipalatinsk, Dostoevsky revived his faith by looking frequently at the stars. Wrangel said that he was "rather pious, but did not often go to church, and disliked priests, especially the Siberian ones. But he spoke about Christ ecstatically." Two pilgrimages and two works by Demetrius of Rostov, an archbishop who influenced Ukrainian and Russian literature by composing groundbreaking religious plays, strengthened his beliefs. Through his visits to western Europe and discussions with Herzen, Apollon Grigoryev, and Nikolay Strakhov, Dostoevsky discovered the *Pochvennichestvo* movement and the theory that the Catholic Church had adopted the principles of rationalism, legalism, materialism, and individualism from ancient Rome and had passed on its philosophy to Protestantism and consequently to atheistic socialism.

## Themes and style

Manuscript of *Demons*

Dostoevsky's canon includes novels, novellas, novelettes, short stories, essays, pamphlets, limericks, epigrams and poems. He wrote more than 700 letters, a dozen of which are lost.

Dostoevsky expressed religious, psychological, and philosophical ideas in his writings. His works explore such themes as suicide, poverty, human manipulation, and morality. Psychological themes include dreaming, first seen in "White Nights", and the father-son relationship, beginning in *The Adolescent*. Most of his works demonstrate a vision of the chaotic sociopolitical structure of contemporary Russia. His early works viewed society (for example, the differences between poor and rich) through the lens of literary realism and naturalism. The influences of other writers, particularly evident in his early works, led to accusations of plagiarism, but his style gradually became more individual. After his release from prison, Dostoevsky incorporated religious themes, especially those of Russian Orthodoxy, into his writing. Elements of gothic fiction, romanticism, and satire are observable in some of his books. He frequently used autobiographical or semi-autobiographical details.

An important stylistic element in Dostoevsky's writing is polyphony, the simultaneous presence of multiple narrative voices and perspectives. Kornelije Kvas wrote that Bakhtin's theory of "the polyphonic novel and Dostoevsky's dialogicness of narration postulates the non-existence of the "final" word, which is why the thoughts, emotions and experiences of the world of the narrator and his/her characters are reflected through the words of another, with which they can never fully blend."

## Legacy

### Reception and influence

Dostoevsky monument in Dresden (Germany)

Dostoevsky is regarded as one of the greatest and most influential novelists of the Golden Age of Russian literature. Leo Tolstoy admired some of Dostoevsky's works, particularly *The House of the Dead*, which he saw as exalted religious art, inspired by deep faith and love of humanity. Albert Einstein called Dostoevsky a "great religious writer" who explores "the mystery of spiritual existence." Sigmund Freud ranked Dostoevsky second only to William Shakespeare as a creative writer, and called *The Brothers Karamazov* "the most magnificent novel ever written." Friedrich Nietzsche called Dostoevsky "the only psychologist from whom I had something to learn" and described him as being "among the most beautiful strokes of fortune in my life." The Russian literary theorist Mikhail Bakhtin's analysis of Dostoevsky came to be at the foundation of his theory of the novel. Bakhtin argued that Dostoevsky's use of polyphony was a major advancement in the development of the novel as a genre.

In his posthumous collection of sketches *A Moveable Feast*, Ernest Hemingway stated that in Dostoevsky "there were things believable and not to be believed, but some so true that they changed you as you read them; frailty and madness, wickedness and saintliness, and the insanity of gambling were there to know". James Joyce praised Dostoevsky's prose: "[...] he is the man more than any other who has created modern prose, and intensified it to its present-day pitch. It was his explosive power which shattered the Victorian novel with its simpering maidens and ordered commonplaces; books which were without imagination or violence." In her essay *The Russian Point of View*, Virginia Woolf said, "Out of Shakespeare there is no more exciting reading". Franz Kafka called Dostoevsky his "blood-relative" and was heavily influenced by his works, particularly *The Brothers Karamazov* and *Crime and Punishment*, both of which profoundly influenced *The Trial*. Hermann Hesse enjoyed Dostoevsky's work and said that to read him is like a "glimpse into the havoc". The Norwegian novelist Knut Hamsun wrote that "no one has analyzed the complicated human structure as Dostoyevsky. His psychologic sense is overwhelming and visionary." Writers associated with cultural movements such as surrealism, existentialism and the Beats cite Dostoevsky as an influence, and he is regarded as a forerunner to Russian symbolism, expressionism and psychoanalysis.

J. M. Coetzee featured Dostoevsky as the protagonist in his 1997 novel *The Master of Petersburg*. The famous Malayalam novel *Oru Sankeerthanam Pole* by Perumbadavam Sreedharan deals with the life of Dostoevsky and his love affair with Anna.

### Honours

[).jpg)

Soviet Union stamp, 1971

In 1956, an olive-green postage stamp dedicated to Dostoevsky was released in the Soviet Union, with a print run of 1,000 copies. The Dostoevsky Museum was opened on 12 November 1971 in the apartment where he wrote his first and final novels. A crater on Mercury was named after him in 1979, and a minor planet discovered in 1981 by Lyudmila Karachkina was named 3453 Dostoevsky. Music critic and broadcaster Artemy Troitsky has hosted the radio show "FM Достоевский" (FM Dostoevsky) since 1997. Viewers of the TV show *Name of Russia* voted him the ninth greatest Russian of all time, just after Dmitry Mendeleev, and just ahead of ruler Ivan IV. An Eagle Award-winning TV series directed by Vladimir Khotinenko about Dostoevsky's life was screened in 2011.

Numerous memorials were inaugurated in cities and regions such as Moscow, Saint Petersburg, Novosibirsk, Omsk, Semipalatinsk, Kusnetsk, Darovoye, Staraya Russa, Lyublino, Tallinn, Dresden, Baden-Baden and Wiesbaden. The Dostoyevskaya metro station in Saint Petersburg was opened on 30 December 1991, and the station of the same name in Moscow was opened on 19 June 2010, the 75th anniversary of the Moscow Metro. The Moscow station is decorated with murals by artist Ivan Nikolaev depicting scenes from Dostoevsky's works, such as controversial suicides.

In 2021, Kazakhstan celebrated the 200th anniversary of Dostoevsky's birth.

### Criticism

Dostoevsky's work did not always gain a positive reception. Some critics, such as Nikolay Dobrolyubov, Ivan Bunin and Vladimir Nabokov, viewed his writing as excessively psychological and philosophical rather than artistic. Others found fault with chaotic and disorganised plots, and others, like Turgenev, objected to "excessive psychologizing" and too-detailed naturalism. His style was deemed "prolix, repetitious and lacking in polish, balance, restraint and good taste". Saltykov-Shchedrin, Nikolay Mikhaylovsky and others criticised his puppet-like characters, most prominently in *The Idiot*, *Demons* (*The Possessed*, *The Devils*) and *The Brothers Karamazov*. These characters were compared to those of Hoffmann, an author whom Dostoevsky admired.

Basing his estimation on stated criteria of enduring art and individual genius, Nabokov judges Dostoevsky "not a great writer, but rather a mediocre one — with flashes of excellent humour but, alas, with wastelands of literary platitudes in between." Nabokov complains that the novels are peopled by "neurotics and lunatics" and states that Dostoevsky's characters do not develop: "We get them all complete at the beginning of the tale and so they remain." He finds the novels full of contrived "surprises and complications of plot", which are effective when first read, but on second reading, without the shock and benefit of these surprises, appear loaded with "glorified cliché". The Scottish poet and critic Edwin Muir, however, addressed criticism regarding the quality of Dostoevsky's characters, noting that "regarding the "oddness" of Dostoevsky's characters, it has been pointed out that they perhaps only seem "pathological", whereas in reality they are "only visualised more clearly than any figures in imaginative literature".

### Reputation

Dostoevsky's books have been translated into more than 170 languages. The German translator Wilhelm Wolfsohn published one of the first translations, parts of *Poor Folk*, in an 1846–1847 magazine, and a French translation followed. French, German and Italian translations usually came directly from the original, while English translations were second-hand and of poor quality. The first English translations were by Marie von Thilo in 1881, but the first highly regarded ones were produced between 1912 and 1920 by Constance Garnett. Her flowing and easy translations helped popularise Dostoevsky's novels in anglophone countries, and Bakhtin's *Problems of Dostoevsky's Creative Art* (1929) (republished and revised as *Problems of Dostoevsky's Poetics* in 1963) provided further understanding of his style.

Dostoevsky's works have been interpreted in film and on stage in many different countries. Princess Varvara Dmitrevna Obolenskaya was among the first to propose staging *Crime and Punishment*. Dostoevsky did not refuse permission, but he advised against it, as he believed that "each art corresponds to a series of poetic thoughts, so that one idea cannot be expressed in another non-corresponding form". His extensive explanations in opposition to the transposition of his works into other media were groundbreaking in fidelity criticism. He thought that just one episode should be dramatised, or an idea should be taken and incorporated into a separate plot. According to critic Alexander Burry, some of the most effective adaptions are Sergei Prokofiev's opera *The Gambler*, Leoš Janáček's opera *From the House of the Dead*, Akira Kurosawa's film *The Idiot* and Andrzej Wajda's film *The Possessed*.

After the 1917 Russian Revolution, passages of Dostoevsky books were sometimes shortened, although only two books were censored: *Demons* and *Diary of a Writer*. His philosophy, particularly in *Demons*, was deemed anti-capitalist but also anti-communist and reactionary. According to historian Boris Ilizarov, Stalin read Dostoevsky's *The Brothers Karamazov* several times.

## Works

Dostoevsky's works of fiction include 16 novels and novellas, 16 short stories, and 5 translations. Many of his longer novels were first published in serialized form in literary magazines and journals. The years given below indicate the year in which the novel's final part or the first complete book edition was published. In English, many of his novels and stories are known by different titles.

### Major works

#### Poor Folk

*Poor Folk* is an epistolary novel that depicts the relationship between the small, elderly official Makar Devushkin and the young seamstress Varvara Dobroselova, remote relatives who write letters to each other. Makar's tender, sentimental adoration for Varvara and her confident, warm friendship for him explain their evident preference for a simple life, although it keeps them in humiliating poverty. An unscrupulous merchant finds the inexperienced girl and hires her as his housewife and guarantor. He sends her to a manor somewhere on a steppe, while Makar alleviates his misery and pain with alcohol.

The story focuses on poor people who struggle with their lack of self-esteem. Their misery leads to the loss of their inner freedom, to dependence on the social authorities, and to the extinction of their individuality. Dostoevsky shows how poverty and dependence are indissolubly aligned with deflection and deformation of self-esteem, combining inward and outward suffering.

#### Notes from Underground

*Notes from Underground* is split into two stylistically different parts, the first essay-like, the second in narrative style. The protagonist and first-person narrator is an unnamed 40-year-old civil servant known as The Underground Man. The only known facts about his situation are that he has quit the service, lives in a basement flat on the outskirts of Saint Petersburg and finances his livelihood from a modest inheritance.

The first part is a record of his thoughts about society and his character. He describes himself as vicious, squalid and ugly; the chief focuses of his polemic are the "modern human" and his vision of the world, which he attacks severely and cynically, and towards which he develops aggression and vengefulness. He considers his own decline natural and necessary. Although he emphasises that he does not intend to publish his notes for the public, the narrator appeals repeatedly to an ill-described audience, whose questions he tries to address.

In the second part, he describes scenes from his life that are responsible for his failure in personal and professional life and in his love life. He tells of meeting old school friends, who are in secure positions and treat him with condescension. His aggression turns inward onto himself and he tries to humiliate himself further. He presents himself as a possible saviour to the poor prostitute Liza, advising her to reject self-reproach when she looks to him for hope. Dostoevsky added a short commentary saying that although the storyline and characters are fictional, such things were inevitable in contemporary society.

The Underground Man was very influential on philosophers. His alienated existence from the mainstream influenced modernist literature.

#### Crime and Punishment

The novel *Crime and Punishment* has received both critical and popular acclaim. It remains one of the most influential and widely read novels in Russian literature, and has been sometimes described as Dostoevsky's magnum opus.

*Crime and Punishment* follows the mental anguish and moral dilemmas of Rodion Raskolnikov, an impoverished ex-student in Saint Petersburg who plans to kill an unscrupulous pawnbroker, an old woman who stores money and valuable objects in her flat. He theorises that with the money he could liberate himself from poverty and go on to perform great deeds, and seeks to convince himself that certain crimes are justifiable if they are committed in order to remove obstacles to the higher goals of "extraordinary" men. Once the deed is done, however, he finds himself racked with confusion, paranoia, and disgust. His theoretical justifications lose all their power as he struggles with guilt and horror and confronts both the internal and external consequences of his deed.

Strakhov remarked that "Only *Crime and Punishment* was read in 1866" and that Dostoevsky had managed to portray a Russian person aptly and realistically. In contrast, Grigory Eliseev of the radical magazine *The Contemporary* called the novel a "fantasy according to which the entire student body is accused without exception of attempting murder and robbery". The *Encyclopædia Britannica* describes *Crime and Punishment* as "a masterpiece" and "one of the finest studies of the psychopathology of guilt written in any language."

#### The Idiot

The title is an ironic reference to the central character of the novel, Prince Lev Nikolayevich Myshkin, a young man whose goodness, open-hearted simplicity and guilelessness lead many of the more worldly characters he encounters to mistakenly assume that he lacks intelligence and insight. In the character of Prince Myshkin, Dostoevsky set himself the task of depicting "the positively good and beautiful man." The novel examines the consequences of placing such a singular individual at the center of the conflicts, desires, passions and egoism of worldly society, both for the man himself and for those with whom he becomes involved.

Joseph Frank describes *The Idiot* as "the most personal of all Dostoevsky's major works, the book in which he embodies his most intimate, cherished, and sacred convictions." It includes descriptions of some of his most intense personal ordeals, such as epilepsy and mock execution, and explores moral, spiritual and philosophical themes consequent upon them. His primary motivation in writing the novel was to subject his own highest ideal, that of true Christian love, to the crucible of contemporary Russian society.

#### Demons

*Demons* is a social and political satire, a psychological drama, and a large-scale tragedy. Joyce Carol Oates has described it as Dostoevsky's most confused and violent novel, and his most satisfactorily "tragic' work". According to Ronald Hingley, it is Dostoevsky's "greatest onslaught on Nihilism", and "one of humanity's most impressive achievements — perhaps even its supreme achievement — in the art of prose fiction."

*Demons* is an allegory of the potentially catastrophic consequences of the political and moral nihilism that was becoming prevalent in Russia in the 1860s. A fictional town descends into chaos as it becomes the focal point of an attempted revolution, orchestrated by master conspirator Pyotr Verkhovensky. The mysterious aristocratic figure of Nikolai Stavrogin — Verkhovensky's counterpart in the moral sphere — dominates the book, exercising an extraordinary influence over the hearts and minds of almost all the other characters. The idealistic, Western-influenced generation of the 1840s, epitomised in the character of Stepan Verkhovensky (who is both Pyotr Verkhovensky's father and Nikolai Stavrogin's childhood teacher), is presented as the unconscious progenitors and helpless accomplices of the "demonic" forces that take possession of the town.

#### The Brothers Karamazov

*The Brothers Karamazov* is Dostoevsky's largest work. It received both critical and popular acclaim and, like *Crime and Punishment*, is often cited as his magnum opus. Composed of 12 "books", the novel tells the story of three brothers: the novice monk Alyosha, the non-believer Ivan, and the soldier Dmitri. The main plot is the death of their father, Fyodor Karamazov, while other parts are philosophical and religious arguments by Father Zosima to Alyosha.

The most famous chapter is "The Grand Inquisitor", a parable told by Ivan to Alyosha about Christ's Second Coming in Seville, Spain, in which Christ is imprisoned by a ninety-year-old Catholic Grand Inquisitor. Instead of answering him, Christ gives him a kiss, and the Inquisitor subsequently releases him, telling him not to return. The tale has been misunderstood as a defence of the Inquisitor, but some, such as Romano Guardini, argue that the Christ of the parable was Ivan's own interpretation of Christ, "the idealistic product of the unbelief". Ivan, however, has stated that he is against Christ. Most contemporary critics and scholars agree that Dostoevsky is attacking Roman Catholicism and socialist atheism, both represented by the Inquisitor. He warns the readers against a terrible revelation in the future, referring to the Donation of Pepin around 750 and the Spanish Inquisition in the 16th century, which in his view corrupted true Christianity.

Sigmund Freud wrote an essay called "Dostoevsky and Parricide" (German: Dostojewski und die Vatertötung) as an introductory article to a scholarly collection on *The Brothers Karamazov*.

### Bibliography

#### Novels and novellas

- (1846) *Poor Folk*
- (1846) *The Double*
- (1847) *The Landlady* (novella)
- (1849) *Netochka Nezvanova* (unfinished)
- (1859) *Uncle's Dream* (novella)
- (1859) *The Village of Stepanchikovo*
- (1861) *Humiliated and Insulted*
- (1862) *The House of the Dead*
- (1864) *Notes from Underground* (novella)
- (1866) *Crime and Punishment*
- (1866) *The Gambler*
- (1869) *The Idiot*
- (1870) *The Eternal Husband*
- (1872) *Demons* (also titled: *The Possessed*, *The Devils*)
- (1875) *The Adolescent*
- (1880) *The Brothers Karamazov*

#### Short stories

- (1846) "Mr. Prokharchin"
- (1847) "Novel in Nine Letters"
- (1848) "Another Man's Wife and a Husband Under the Bed" (merger of "Another Man's Wife" and "A Jealous Husband")
- (1848) "A Weak Heart"
- (1848) "Polzunkov"
- (1848) "An Honest Thief"
- (1848) "A Christmas Tree and a Wedding"
- (1848) "White Nights"
- (1849) "A Little Hero"
- (1862) "A Nasty Story"
- (1865) "The Crocodile"
- (1873) "Bobok"
- (1876) "The Heavenly Christmas Tree" (also titled: "The Beggar Boy at Christ's Christmas Tree")
- (1876) "A Gentle Creature" (also titled: "The Meek One")
- (1876) "The Peasant Marey"
- (1877) "The Dream of a Ridiculous Man"

#### Essay collections

- *Winter Notes on Summer Impressions* (1863)
- *A Writer's Diary* (1873–1881)

#### Translations

- (1843) *Eugénie Grandet* (Honoré de Balzac)
- (1843) *La dernière Aldini* (George Sand)
- (1843) *Mary Stuart* (Friedrich Schiller)

#### Personal letters

- (1912) *Letters of Fyodor Michailovitch Dostoevsky to His Family and Friends* by Fyodor Mikhailovich Dostoevsky (Author), translator Ethel Colburn Mayne Kessinger Publishing, LLC (26 May 2006)
 ISBN 978-1-4286-1333-1

#### Posthumously published notebooks

- (1922) *Stavrogin's Confession & the Plan of the Life of a Great Sinner* – English translation by Virginia Woolf and S.S. Koteliansky
