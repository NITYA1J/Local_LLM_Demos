---
title: "Fathers and Sons (novel)"
source: "https://en.wikipedia.org/wiki/Fathers_and_Sons_%28novel%29"
source_type: "Wikipedia (English)"
license: "CC BY-SA 4.0"
retrieved: "2026-06-29"
---

# Fathers and Sons (novel)

1862 novel by Ivan Turgenev

Fathers and Sons

***Fathers and Sons*** (Russian: «Отцы и дети»; *Otcy i deti*,

IPA:; pre-1918 spelling Отцы и дѣти), literally ***Fathers and Children***, is an 1862 novel by Ivan Turgenev, published in Moscow by Grachev & Co on 23 February 1862. It is one of the most acclaimed Russian novels of the 19th century.

## Plot summary

University graduate Arkady Kirsanov returns to his father's modest estate, called Marino. Arkady brings his friend, Yevgeny Bazarov. His father, Nikolay, gladly receives the two young men at his estate, but Nikolay's brother, Pavel, soon becomes upset by the strange new philosophy called "nihilism" that the young men advocate.

Nikolay, initially delighted to have his son return home, slowly begins to feel uneasy. A certain awkwardness develops in his regard toward his son, as Arkady's radical views, much influenced by Bazarov, make Nikolay's own beliefs feel dated. Nikolay has always tried to stay as current as possible, by doing things such as visiting his son at school so the two can stay as close as they can, but this in Nikolay's eyes has failed. To complicate this, the father has taken a servant, Fenechka, into his house to live with him and has already had a son by her, named Mitya. Arkady, however, is not troubled by the relationship; on the contrary, he is delighted by the addition of a younger brother.

The two young men stay at Marino for some weeks, then decide to visit a relative of Arkady's. There, they observe the local gentry and meet Madame Anna Sergevna Odintsova, an elegant woman of independent means, who cuts a seductively different figure from conventional types of the local provincial society. Both are greatly attracted to her, and she, intrigued by Bazarov's singular manner, invites them to spend a few days at her estate, Nikolskoye.

At Nikolskoye, they also meet Katya, Madame Odintsova's sister. Although they stay for just a short time, Arkady steadily becomes more independent of Bazarov's influence. Bazarov finds falling in love distressing because it runs counter to his nihilist beliefs. Eventually, prompted by Madame Odintsova's own cautious expressions of attraction to him, he announces that he loves her. She does not respond positively to his declaration; she finds his devaluation of feelings and of the aesthetic side of existence unattractive. She does not see the possibility of a good future with him. After his avowal of love, and her failure to make a similar declaration, Bazarov proceeds to his parents' home, and Arkady goes with him.

At Bazarov's home, they are received enthusiastically by his parents, who adore him. Bazarov's social cynicism is still on display as he settles back into his own family's home again. Arkady, who has delighted Bazarov's father by assuring him that his son has a brilliant future in store, reproves his friend for his brusqueness. Later, Bazarov and Arkady nearly come to blows after Bazarov speaks insultingly of Arkady's uncle and chides Arkady for expressing himself too romantically. Arkady becomes more openly skeptical of Bazarov's ideals. After a brief stay, much to the parents' disappointment, they decide to return to Marino, stopping on the way to see Madame Odintsova, who receives them coolly. Embarrassed, they leave almost immediately and return to Arkady's home.

Arkady remains for only a few days and makes an excuse to leave in order to go to Nikolskoye again. Once there, he realizes he is not in love with Odintsova, but instead with her sister Katya. Bazarov stays at Marino to do some scientific research, and tension between him and Pavel increases. Bazarov enjoys talking with Fenechka and playing with her child, and one day he kisses her, against her will. Pavel observes this kiss and challenges Bazarov to a duel. Pavel is wounded in the leg, and Bazarov must leave Marino, going to his parents' home. Meanwhile, Arkady and Katya have fallen in love and have become engaged.

While back at home, Bazarov begins to help his father as a country doctor. He cannot keep his mind on his work, though, and while performing an autopsy, he cuts himself and becomes infected. On his deathbed, he sends for Madame Odintsova, who arrives just in time to hear Bazarov tell her how beautiful she is. She kisses him on the forehead and leaves; Bazarov dies the following day.

Arkady marries Katya and assumes the management of his father's estate. His father marries Fenechka and is delighted to have Arkady home with him. The novel closes with a scene of Bazarov's parents praying by his graveside.

## Major characters

In order of appearance 

*Chapter 1*

> The country through which they were driving was not in the least picturesque.... Slowly Arkady's heart sank.... the peasants whom they met on the way were all in rags and mounted on the sorriest little nags; willows with broken branches and bark hanging in strips stood like tattered beggars on the roadside; emaciated and shaggy cows, gaunt with hunger, were greedily tearing up the grass along the ditches.... "No," thought Arkady, "there is no prosperity here... It just can't go on like this: this must all be transformed..."

— Chapter 3

- **Nikoláy Petróvich Kirsánov** – A gentleman in his early forties, a widower, "quite grey now, stoutish and a trifle bent," a liberal democrat, father of Arkády, brother of Pavel; should have followed his father's career in the army but broke his leg on the day he was commissioned and had to go into the civil service; owns Marino, "a respectable little property of his consisting of a couple of hundred serfs—or five thousand acres." He is thrilled to have his son back from college.

*Chapter 2*

- **Arkády Nikoláyevich Kirsánov** – Son of Nikoláy Petróvich; having recently graduated from St. Petersburg University, he brings his friend Bazarov home to Marino. He has become a nihilist more from Bazarov's influence than from conviction. He becomes enamored of Anna Sergeyevna Odinisov, but cannot compete for her affections with his fascinating friend Bazarov. Later he falls in love with Anna Sergeyevna's quiet, modest young sister Katya and marries her.
- **Yevgény (Enyushka) Vasílevich Bazárov** – A medical student and nihilist, in which role he serves as a mentor to Arkady, and as a challenger to the liberal ideas of the Kirsanov brothers and the traditional Russian Orthodox feelings of his own parents. "A long thin face with a broad forehead...large greenish eyes and drooping, sandy whiskers — the whole animated by a tranquil smile betokening self-assurance and intelligence." He eventually dies of pyaemia carelessly contracted during a medical examination, accepting his fate with calm resignation.

*Chapter 4*

> "In my room there's an English washstand, but the door won't fasten. Anyhow, that's something to be encouraged—English washstands spell progress!"

— Chapter 4

- **Prokófyich** – a servant of the Kirsánovs's; "A man of about sixty... white-haired, lean and dark-complexioned."
- **Pável Petróvich Kirsánov** – Nikoláy Petróvich’s brother; "...of medium height... looked about forty-five... close-cropped grey hair... his face the colour of old ivory but without a wrinkle... unusually regular and clean-cut features... perfumed mustaches." A bourgeois with aristocratic pretensions ("an exquisite pink hand having long tapering pink nails"), he prides himself on his refinement but, like his brother, is reform-minded. Although he recognizes Bazarov as the son of a local doctor, he detests him "with every fiber of his being," thinking him "an arrogant, impudent fellow, a cynic and a vulgarian."

> Nowhere does time fly as it does in Russia; in prison, they say, it flies even faster.

— Chapter 7

- **"Fénechka"** (Feodósya Nikoláyevna) – "...a young woman of about three and twenty with a soft white skin, dark hair and eyes, red childishly-pouting lips and small delicate hands." Daughter of the late housekeeper at Marino with whom Nikoláy Petróvich has fallen in love and fathered a son, named Mitya; Arkady welcomes having a little half-brother. The implied obstacles to marriage are difference in class, and perhaps Nikoláy Petróvich's previous marriage — the burden of 'traditionalist' values.

> **On nihilism:** 
> "We base our conduct on what we find useful," went on Bazarov. "In these days the most useful thing we can do is to repudiate—and so we repudiate." 
> "Everything?" 
> "Everything." 
> "What? Not only art, poetry... but also... I am afraid to say it..." 
> "Everything," Bazarov repeated with indescribable composure.

— Chapter 10

*Chapter 12*

- **Matvéi Ilyich Kolyázin** – A cousin of the Kirsanov brothers who serves as the inspector of the provincial governor in a nearby town. He is pompous and self-important but "he was always being made a fool of, and any moderately experienced official could twist him round his finger."
- **Víktor Sítnikov** – A pompous and foolhardy friend of Bazarov who joins populist ideals and groups. Like Arkady, he is heavily influenced by Bazarov in his ideals. "I appreciate the comforts of life...but that doesn't prevent me from being a liberal."

*Chapter 13*

- **Avdótya (Yevdoksíya) Nikitíshna Kukshiná** – An emancipated woman who lives in the town where Matvei Ilyich is posted. Kukshina is independent but rather eccentric and incapable as a proto-feminist, despite her potential.

> It is well known that every fifth year sees our provincial towns burnt to the ground.

— Chapter 13

*Chapter 14*

- **Ánna Sergéyevna Odintsóva** – A wealthy widow, 29 years old, who entertains the nihilist friends at her estate; "...rather a strange person. Having no prejudices of any kind, and no strong convictions even, she was not put off by obstacles and she had no goal in life...Arkady decided he had never yet met such a fascinating woman. The sound of her voice haunted his ears...her every movement was wonderfully flowing and natural." However, the young Arkady does not fascinate her the way the worldly Bazarov does. They experience a rift, but she hurries to his bedside upon hearing that he's dying.

*Chapter 16*

> "We know more or less what causes physical ailments; and moral diseases are caused by the wrong sort of education... by the disordered state of society. Reform society and there will be no more diseases... in a properly organized society it won't matter a jot whether a man is stupid or clever, bad or good." 
> "Yes, I see. They will all have identical spleens." 
> "Precisely, madame."

— Chapter 16

- **Yekaterína (Kátya) Sergéyevna Lókteva** – The younger sister of Anna: "...a girl of eighteen with black hair, an olive complexion, a rather round but pleasing face and small dark eyes." She lives comfortably with her sister but lacks confidence, finding it hard to escape Anna Sergeevna's shadow. This shyness makes her and Arkady’s love slow to realize itself.
- **The Princess** – Ánna Sergéyevna's aunt, "...a small shriveled woman with a clenched fist of a face and glaring spiteful eyes under a grey wig..." Rude and overbearing but essentially ignored by the household.

*Chapter 20*

- **Vasíly Ivánovich Bazárov** – Bazarov’s father. A retired army surgeon, and a small countryside land/serf holder. Educated and enlightened, he nonetheless feels, like many of the characters, that rural isolation has left him out of touch with modern ideas. He thus retains loyalty to traditionalist ways, manifested particularly in devotion to God and to his son Yevgeny. "'A comical old chap with a heart of gold'," in his son's words.
- **Arína Vlásevna Bazárova** – Bazarov’s mother. A very traditional woman of the 15th-century Moscovy style aristocracy and a pious follower of Orthodox Christianity, woven with folk tales and falsehoods. She loves her son deeply but is also terrified of him and his rejection of all beliefs.

## Historical context and notes

> "So... you were convinced of all this and decided not to do anything serious yourselves." 
> "And decided not to do anything serious," Bazarov repeated grimly.... 
> "But to confine yourselves to abuse?" 
> "To confine ourselves to abuse." 
> "And that is called nihilism?" 
> "And that is called nihilism," Bazarov repeated again, this time with marked insolence.

— Chapter 10

The fathers and children of the novel refers to the growing divide between the two generations of Russians, and the character Yevgeny Bazarov, a nihilist who rejects the old order.

Turgenev wrote *Fathers and Sons* as a response to the growing cultural schism that he saw between liberals of the 1830s/1840s and the growing nihilist movement. Both the nihilists (the "sons") and the 1830s liberals (the "fathers") sought Western-based social change in Russia. Additionally, these two modes of thought were contrasted with the Slavophiles, who believed that Russia's path lay in its traditional spirituality.

Turgenev's novel was responsible for popularizing the use of the term nihilism, which became widely used after the novel was published.

*Fathers and Sons* might be regarded as the first wholly modern novel in Russian literature (Gogol's *Dead Souls*, another main contender, was referred to by the author as a poem or epic in prose as in the style of Dante's *Divine Comedy*, and was at any rate never completed). The novel introduces a dual character study, as seen with the gradual breakdown of Bazarov's and Arkady's nihilistic opposition to emotional display, especially in the case of Bazarov's love for Madame Odintsova.

The novel is also the first Russian work to gain prominence in the Western world, eventually gaining the approval of well established novelists Gustave Flaubert, Guy de Maupassant, and Henry James.

The Bolshevik revolutionary Vladimir Bazarov adopted his pseudonym from the character of Yevgeny Bazarov in this novel.

## Adaptations

### Stage

Canadian playwright George F. Walker's 1988 play *Nothing Sacred* is a stage adaptation of *Fathers and Sons*. Irish playwright Brian Friel has also adapted the novel, under the same title.

### Television

In 1971 the book was adapted as a television miniseries with the same title in the United Kingdom.

In Pakistan, the novel was adapted as a drama serial in 1974 with *Qurbatain aur Faasley* on Pakistan Television Network.

## English translations

1. Eugene Schuyler (1867)
2. Constance Garnett (1895, as *Fathers and Children*)
 1. Revised by Ralph E. Matlaw (1966, retitled *Fathers and Sons*)
 2. Revised by Elizabeth Cheresh Allen (1994, retitled *Fathers and Sons*)
3. Isabel F. Hapgood (1903, as *Fathers and Children*)
4. C. J. Hogarth (1921)
5. Richard Hare (1947, as *Fathers and Children*)
6. Harry Stevens (1950)
7. Barbara Makanowitzky (1959)
8. Bernard Guilbert Guerney (1961)
9. George Reavey (1961)
10. Bernard Isaacs (1962)
11. Avril Pyman (1962, as *Fathers and Children*)
12. Rosemary Edmonds (1965)
13. Richard Freeborn (1991)
14. Michael R. Katz (1994, originally published as *Fathers and Sons*; retitled *Fathers and Children* in 2008)
15. Peter Carson (2009)
16. Michael Pursglove (2010, as *Fathers and Children*)
17. Nicolas Pasternak Slater and Maya Slater (2022, as *Fathers and Children*)
